<?php


require("cfg.php");


if (!$sys->IsInstalled() && $_GET['do'] != 'install')
	{
	header("Location: " . BASE_URL . "/index.php?do=install");
	}
elseif ($user->id != null)
	{
	if (!$user->ValidSession())
		{
		setcookie(COOKIE_USER, null, -1, "/");
		setcookie(COOKIE_PASS, null, -1, "/");
		setcookie(COOKIE_SESS, null, -1, "/");
		$page->Forbidden($MES['invalid_session']);
		}
	}


$survey = new Survey($_GET['id']);


if ($_GET['do'] == 'ajax')
	{
	$page->AjaxHeaders();
	if ($_GET['what'] == 'account')
		{
		$u = new User($_POST['id']);
		$u->name = $_POST['username'];
		$u->first_name = $_POST['first_name'];
		$u->last_name = $_POST['last_name'];
		$u->email = $_POST['email'];
		$u->password = $_POST['password'];
		$u->type = $_POST['type'];
		$u->company = $_POST['company'];
		$u->survey = $_POST['survey'];
		$u->assigned = $_POST['assigned'];
		$u->eac = $_POST['eac'];
		$u->logo = $_FILES['img'];
		// edit the account
		if ($u->id != null)
			{
			$u->Update();
			}
		// create the account
		else
			{
			$u->Create();
			}
		echo "1";
		}
	elseif ($_GET['what'] == 'delete')
		{
		if ($_GET['op'] == 1)
			{
			$s = new Survey($_GET['id']);
			$s->Delete();
			}
		elseif ($_GET['op'] == 2)
			{
			$u = new User($_GET['id']);
			$u->Delete();
			}
		elseif ($_GET['op'] == 3)
			{
			DB::Query("DELETE FROM `" . TBLPRE . "evaluations` WHERE `id` = '" . DB::Escape($_GET['id']) . "' LIMIT 1");
			}
		}
	elseif ($_GET['what'] == 'check_username')
		{
		$u = new User($_POST['id']);
		if (!$u->UserNameIsValid($_POST['username']))
			{
			echo 3;
			}
		elseif ($u->UserNameIsTaken($_POST['username']))
			{
			echo 2;
			}
		else
			{
			echo 1;
			}
		}
	elseif ($_GET['what'] == 'list')
		{
		class_exists('Manage') || require("lib/Manage.php");
		$man = new Manage;
		$man->type = $_GET['type'];
		$man->sortField = $_GET['sfield'];
		$man->sortMode = $_GET['smode'];
		$man->useContainer = false;
		if (!preg_match("/^[0-9]{1,10}$/", $_GET['start']))
			{
			$start = 0;
			}
		else
			{
			$start = $_GET['start'];
			}
		$man->start = $start;
		$man->survey = new Survey($_GET['survey']);
		$man->user = new User ($_GET['user']);
		echo $man->GetList();
		}
	elseif ($_GET['what'] == 'sform')
		{
		if ($_GET['op'] == 'com_dialog')
			{
			echo $survey->NewCompetencyDialog();
			}
		elseif ($_GET['op'] == 'beh_dialog')
			{
			echo $survey->NewBehaviorDialog();
			}
		elseif ($_GET['op'] == 'add_com')
			{
			$survey->coms["{$_GET['cid']}"] = $_POST['new_competency'];
			echo $survey->FormCompetency($_GET['cid']);
			}
		elseif ($_GET['op'] == 'add_beh')
			{
			echo $survey->FormBehavior($_GET['cid'], $_GET['bid']);
			}
		elseif ($_GET['op'] == 'writein')
			{
			echo $survey->WriteIn($_GET['wid']);
			}
		}
	elseif ($_GET['what'] == 'company_surveys')
		{
		$p = new User($_GET['company']);
		$q = "SELECT `id`, `name` FROM `" . TBLPRE . "surveys` WHERE `partner` = '" . DB::Escape($_GET['company']) . "' && `visible` = '1' ORDER BY `name`";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			$d .= " &#187; ";
			$d .= "<select class='oef-home_select' id='oef-company-surveys'>";
			while ($r = mysql_fetch_array($res))
				{
				$d .= "<option value='{$r['id']}'>{$r['name']}</option>";
				}
			$d .= "</select>";
			$d .= " &#187; ";
			$d .= "<input type='text' class='oef-home_input' id='oef-eac' value=\"" . htmlspecialchars($MES['access_code']) . "\" onclick=\"this.value='';\"/>";
			$d .= " &#187; ";
			$d .= "<input type='button' class='oef-home_button' value=\"" . htmlspecialchars($MES['lets_get_started']) . "\" onclick=\"loadSurvey();\"/>";
			echo $d;
			}
		else
			{
			echo " " . $MES['no_surveys_for_company'];
			}
		}
	elseif ($_GET['what'] == 'evaluated_users')
		{
		$q = "SELECT eva.assessed, usr.first_name, usr.last_name FROM `" . TBLPRE . "evaluations` AS eva, `" . TBLPRE . "users` as usr WHERE eva.survey = '" . DB::Escape($_GET['survey']) . "' && eva.assessed = usr.id";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			$evalArray = array();
			while ($r = mysql_fetch_array($res))
				{
				$evalArray["{$r['assessed']}"] = $r['first_name'] . " " . $r['last_name'];
				}
			$evalArray = array_unique($evalArray);
			$evalCount = count($evalArray);
			$d .= "<div class='oef-manage_eval_ppl'>" . str_replace('$x', "<span class='oef-manage_eval_ppl_num'>{$evalCount}</span>", $MES['x_people']) . "</div>";
			$d .= "<ul class='oef-manage_eval_list'>";
			asort($evalArray);
			foreach ($evalArray as $e_i => $e_v)
				{
				$d .= "<li class='oef-manage_eval_list_li'><a href='index.php?do=stats&what=users&id={$e_i}'>{$e_v}</a></li>";
				}
			$d .= "</ul>";
			echo $d;
			}
		else
			{
			echo $MES['no_evaluations_for_survey'];
			}
		}
	elseif ($_GET['what'] == 'update_survey_visibility')
		{
		if ($user->type == 2)
			{
			if ($_GET['vis'] == 1)
				{
				$visible = 1;
				}
			else
				{
				$visible = 0;
				}
			$q = "UPDATE `" . TBLPRE . "surveys` SET `visible` = '" . DB::Escape($visible) . "' WHERE `id` = '{$_GET['survey']}' LIMIT 1";
			$res = DB::Query($q);
			}
		}
	elseif ($_GET['what'] == 'assigned_user')
		{
		if ($user->type == 2 || $user->type == 1)
			{
			echo $user->AssignedUser($_GET['u']);			
			}
		}
	elseif ($_GET['what'] == 'assigned_list')
		{
		if ($user->type == 2 || $user->type == 1)
			{
			echo $user->AssignedList($_GET['u']);			
			}
		}
	elseif ($_GET['what'] == 'company_url')
		{
		echo $user->CompanyURL($_POST['company']);
		}
	exit;
	}
elseif ($_GET['do'] == 'manage')
	{
	class_exists('Manage') || require("lib/Manage.php");
	$title = $MES['management'];
	$op = $_GET['op'];
	if ($op == null)
		{
		$op = 'list';
		$man = new Manage;
		}
	if ($_GET['what'] == 'surveys')
		{
		if ($user->type != 2)
			{
			$page->Forbidden();
			}
		$nav .= "<a class='oef-nav_link' href='index.php?do=manage&what=surveys'>{$MES['list_surveys']}</a>";
		$nav .= " | ";
		$nav .= "<a class='oef-nav_link' href='index.php?do=manage&what=surveys&op=form'>{$MES['create_survey']}</a>";
		$page->SetVar('navpane', $page->NavPane($nav));
		if ($op == 'list')
			{
			$title .= " &#187; " . $MES['list_surveys'];
			$man->type = 1;
			$data = $man->GetList();
			}
		elseif ($op == 'form')
			{
			if ($survey->id != null)
				{
				$title .= " &#187; " . $MES['update_survey'];
				}
			else
				{
				$title .= " &#187; " . $MES['create_survey'];
				}
			$data .= $survey->Form();
			}
		}
	elseif ($_GET['what'] == 'users')
		{
		$nav .= "<a class='oef-nav_link' href='index.php?do=manage&what=users'>{$MES['list_users']}</a>";
		$nav .= " | ";
		$nav .= "<a class='oef-nav_link' href='index.php?do=manage&what=users&op=form'>{$MES['create_account']}</a>";
		$page->SetVar('navpane', $page->NavPane($nav));
		if ($op == 'list')
			{
			if ($user->type == 0)
				{
				$page->Forbidden();
				}
			$title .= " &#187; " . $MES['list_users'];
			$man->type = 2;
			$data = $man->GetList();
			}
		elseif ($op == 'form')
			{
			$u = new User($_GET['id']);
			if ($u->id != null)
				{
				$title .= " &#187; " . $MES['update_account'];
				}
			else
				{
				$title .= " &#187; " . $MES['create_account'];
				}
			if ($user->type == 2 || ($user->type == 1 && ($u->id == null || $u->id == $user->id || $u->creator == $user->id)))
				{
				$data = $u->Form();
				}
			else
				{
				$page->Forbidden();
				}
			}
		}
	elseif ($_GET['what'] == 'reports')
		{
		$nav .= "<a class='oef-nav_link' href='index.php?do=manage&what=reports'>{$MES['list_partners']}</a>";
		$page->SetVar('navpane', $page->NavPane($nav));
		if ($op == 'list')
			{
			if ($user->type == 0)
				{
				$page->Forbidden();
				}
			$title .= " &#187; " . $MES['list_partners'];
			$man->type = 4;
			$data = $man->GetList();
			}
		elseif ($op == 'evaluated_users')
			{
			$data .= "<div class='oef-manage'>";
			$data .= "<div class='oef-manage_eval_users'>";
			$data .= "<div class='oef-manage_eval_users_head'>";
			$q = "SELECT `id`, `name` FROM `" . TBLPRE . "surveys` WHERE `partner` = '" . DB::Escape($_GET['partner']) . "' ORDER BY `name`";
			$res = DB::Query($q);
			if (@mysql_num_rows($res) > 0)
				{
				$data .= $MES['select_a_survey'] . " &#187; ";
				$data .= "<select class='oef-manage_eval_select' id='oef-eval-select' onchange=\"toggleEvaluatedSurvey(this);\">";
				$data .= "<option value=''></option>";
				while ($r = mysql_fetch_array($res))
					{
					$data .= "<option value='{$r['id']}'>{$r['name']}</option>";
					}
				$data .= "</select>";
				$data .= "<span id='oef-eval-user-notice' style='display: none;'> &#187; {$MES['evaluated_people']} &#187;</span>";
				}
			else
				{
				$data .= $MES['no_surveys_for_company'];
				}
			//$data .= $MES['following_users_evaluated'];
			$data .= "</div><!-- end oef-manage_eval_users_head -->";
			$data .= "<div class='oef-manage_eval_users_body'>";
			$data .= "<div id='oef-man-eva-sur-ppl'>";
			$data .= "</div><!-- end oef-man-eva-sur-ppl -->";
			$data .= "</div><!-- end oef-manage_eval_users_body -->";
			$data .= "</div><!-- end oef-manage_eval_users -->";
			$data .= "</div><!-- end oef-manage -->";
			}
		elseif ($op == 'company')
			{
			$data .= "<div class='oef-manage'>";
			$data .= "<div class='oef-manage_eval_users'>";
			$data .= "<div class='oef-manage_eval_users_head'>";
			$q = "SELECT `id`, `name` FROM `" . TBLPRE . "surveys` WHERE `partner` = '" . DB::Escape($_GET['partner']) . "' ORDER BY `name`";
			$res = DB::Query($q);
			if (@mysql_num_rows($res) > 0)
				{
				$data .= $MES['select_a_survey'] . " &#187; ";
				$data .= "<select class='oef-manage_eval_select' id='oef-eval-select' onchange=\"toggleEvaluatedSurvey(this);\">";
				$data .= "<option value=''></option>";
				while ($r = mysql_fetch_array($res))
					{
					$data .= "<option value='{$r['id']}'>{$r['name']}</option>";
					}
				$data .= "</select>";
				//$data .= "<span id='oef-eval-user-notice' style='display: none;'> &#187; {$MES['evaluated_people']} &#187;</span>";
				}
			else
				{
				$data .= $MES['no_surveys_for_company'];
				}
			//$data .= $MES['following_users_evaluated'];
			$data .= "</div><!-- end oef-manage_eval_users_head -->";
			$data .= "<div class='oef-manage_eval_users_body'>";
			$data .= "<div id='oef-man-eva-sur'>";
			$data .= "</div><!-- end oef-man-eva-sur -->";
			$data .= "</div><!-- end oef-manage_eval_users_body -->";
			$data .= "</div><!-- end oef-manage_eval_users -->";
			$data .= "</div><!-- end oef-manage -->";
			}
		}
	$page->SetVar('title', $title);
	}
elseif ($_GET['do'] == 'password')
	{
	$uid = $user->id;
	if ($_GET['id'] != null)
		{
		if ($user->type != 2)
			{
			$page->Forbidden();
			}
		$uid = $_GET['id'];
		}
	$u = new User($uid);
	$data .= $u->PasswordForm();
	}
elseif ($_GET['do'] == 'login')
	{
	$page->SetVar('title', $MES['management'] . " &#187; " . $MES['login']);
	$data = $user->LoginForm();
	}
elseif ($_GET['do'] == 'logout')
	{
	$data = $user->Logout();
	}
elseif ($_GET['do'] == 'install' && !$sys->IsInstalled())
	{
	$page->SetVar('title', $MES['install']);
	$data .= $sys->Install();
	}
elseif ($_GET['do'] == 'stats')
	{
	class_exists('Stats') || require("lib/Stats.php");
	$stats = new Stats;
	if ($_GET['what'] == 'users')
		{
		$stats->type == 2;
		$stats->id = $_GET['id'];
		$stats->survey = $_GET['survey'];
		$title = $MES['stats'];
		$uo = new User($_GET['id']);
		$stats->user = $uo;
		if ($_GET['op'] == 'report')
			{
			$nav .= "<a class='oef-nav_link' href='{$_SERVER['REQUEST_URI']}&format=printer'><img src='pics/print_24x24.png' alt='printer version' style='border:0;margin:2px;vertical-align:middle;'/> {$MES['printer_friendly_format']}</a>";
			$page->SetVar('navpane', $page->NavPane($nav));
			$data .= $stats->Report();
			}
		elseif ($_GET['op'] == 'list')
			{
			class_exists('Manage') || require("lib/Manage.php");
			$title .= " &#187; " . $MES['evaluations'];
			$survey = $_GET['survey'];
			$man = new Manage;
			if ($user->type != 2 && $survey->partner != $user->id && $user->id != null)
				{
				$page->Forbidden();
				}
			$title .= " &#187; " . $survey->name;
			$man->type = 3;
			$man->survey = new Survey($survey);
			$man->user = $uo;
			$data = $man->GetList();
			}
		else
			{
			$data .= $stats->MainMenu();
			}
		$page->SetVar('title', $title);
		}
	elseif ($_GET['what'] == 'company')
		{
		$stats->type == 2;
		$stats->id = $_GET['id'];
		$stats->survey = new Survey($_GET['survey']);
		$title = $MES['stats'];
		//$uo = new User($_GET['id']);
		//$stats->user = $uo;
		$clogo = "pics/logos/{$stats->survey->partner}.png";
		if (file_exists($clogo))
			{
			$page->SetVar('logo', "{$stats->survey->partner}.png");
			}
		if ($_GET['op'] == 'report')
			{
			$nav .= "<a class='oef-nav_link' href='{$_SERVER['REQUEST_URI']}&format=printer'><img src='pics/print_24x24.png' alt='printer version' style='border:0;margin:2px;vertical-align:middle;'/> {$MES['printer_friendly_format']}</a>";
			$page->SetVar('navpane', $page->NavPane($nav));
			$data .= $stats->Report();
			}
		elseif ($_GET['op'] == 'list')
			{
			class_exists('Manage') || require("lib/Manage.php");
			$title .= " &#187; " . $MES['evaluations'];
			//$survey = $_GET['survey'];
			$man = new Manage;
			if ($user->type != 2 && $stats->survey->partner != $user->id && $user->id != null)
				{
				$page->Forbidden();
				}
			$title .= " &#187; " . $stats->survey->name;
			$man->type = 3;
			$man->survey = $stats->survey;
			$man->user = $uo;
			$data = $man->GetList();
			}
		else
			{
			$data .= $stats->MainMenu();
			}
		$page->SetVar('title', $title);
		}
	}
elseif ($_GET['id'] != null)
	{
	$page->SetVar('title', $MES['survey'] . " &#187; " . $survey->name);
	$survey->eid = $_GET['evaluation'];
	$partner = new user($survey->partner);
	$survey->cuser = $partner;
	$clogo = "pics/logos/{$partner->id}.png";
	if (file_exists($clogo))
		{
		$page->SetVar('logo', "{$partner->id}.png");
		}
	if ($survey->eid != null)
		{
		if ($user->type != 2 && $survey->partner != $user->id)
			{
			$page->Forbidden();
			}
		$survey->GetEvaluation();
		}
	elseif ($survey->visible != 1 && $user->type != 2)
		{
		$page->Forbidden();
		}
	elseif ($survey->type == 2 && $_GET['eid'] != null)
		{
		$raweac = base64_decode($_GET['eac']);
		$e = new User($_GET['eid']);
		if ($e->eac != $raweac)
			{
			$page->Forbidden($MES['invalid_eac']);
			}
		}
	elseif ($survey->type == 2)
		{
		$eid = $user->GetUserIDFromAC($_GET['eac']);
		if (!$eid)
			{
			$page->Forbidden($MES['invalid_eac']);
			}
		else
			{
			header("Location: index.php?id={$_GET['id']}&eid={$eid}&eac=" . base64_encode($_GET['eac']));
			}
		}
	$data = $survey->Make();
	}
elseif ($_GET['type'])
	{
	if ($_GET['type'] == 2)
		{
		$eid = $user->GetUserIDFromAC($_GET['eac']);
		$employee = new User($eid);
		}
	$q = "SELECT `id` FROM `" . TBLPRE . "surveys` WHERE `partner` = '" . DB::Escape($_GET['company']) . "' && `type` = '" . DB::Escape($_GET['type']) . "' LIMIT 1";
	$res = DB::Query($q);
	$clogo = "pics/logos/{$_GET['company']}.png";
	if (file_exists($clogo))
		{
		$page->SetVar('logo', "{$_GET['company']}.png");
		}
	if (@mysql_num_rows($res) > 0)
		{
		list($sid) = mysql_fetch_array($res);
		}
	else
		{
		$page->Forbidden($MES['no_survey_for_company']);
		}
	if ($_GET['type'] == 2 && !$eid)
		{
		$page->Forbidden($MES['invalid_eac']);
		}
	else
		{
		header("Location: index.php?id={$sid}&eid={$eid}&eac=" . base64_encode($_GET['eac']));
		}
	}
else
	{
	$q = "SELECT `company`, `id` FROM `" . TBLPRE . "users` WHERE `type` = '1' && `company` != ''";
	$res = DB::Query($q);
	if (@mysql_num_rows($res) > 0)
		{
		while ($r = mysql_fetch_array($res))
			{
			if (strtolower(BASE_URL . "/" . $_GET['company']) == strtolower($user->CompanyURL($r['company'])))
				{
				$companyID = $r['id'];
				$companyName = $r['company'];
				break;
				}
			}
		}
	$page->SetVar('title', $MES['home_title']);
	$data .= "<div class='oef-home'>";
	$data .= "<div class='oef-home_welcome'>";
	$data .= $MES['welcome_message'];
	$data .= "</div><!-- end oef-home_welcome -->";
	if ($companyID)//$user->type != 1 && $user->type != 2 && 
		{
		$clogo = "pics/logos/{$companyID}.png";
		if (file_exists($clogo))
			{
			$page->SetVar('logo', "{$companyID}.png");
			}
		$whatArray = array("1"=>$MES['a_customer'], "2"=>$MES['an_employee']);
		$whatSelection = "<select name='what' id='oef-what' onchange=\"toggleWhatPerson(this.value);\">";
		foreach ($whatArray as $w_i => $w_v)
			{
			$whatSelection .= "<option value='{$w_i}'>{$w_v}</option>";
			}
		$whatSelection .= "</select>";
		$intro = $MES['i_am_what_of_company'];
		$intro = str_replace(array('$what', '$company'), array($whatSelection, "<strong>$companyName</strong>"), $intro);
		$data .= "<div class='oef-home_company'>";
		$data .= "<input type='hidden' name='oef-company' id='oef-company' value='{$companyID}'/>";
		$data .= $MES['enter_access_code'];
		$data .= "<div class='oef-home_company_menu'>";
		$data .= "<form onsubmit=\"loadSurvey();return false;\" style='margin:0;padding:0;'>";
		$data .= $intro . " &#187; ";

		$data .= "<span class='oef-home_acode' id='oef-home-acode' style='display: none;'>";
		$data .= $MES['access_code'];
		$data .= " &#187; ";
		$data .= "<input type='text' class='oef-home_input' id='oef-eac' value=\"\" onclick=\"this.value='';\"/>";
		$data .= " &#187; ";
		$data .= "</span>";


		$data .= "<input type='submit' class='oef-home_button' value=\"" . htmlspecialchars($MES['lets_get_started']) . "\" onclick=\"loadSurvey();\"/>";
		$data .= "</form>";

		$data .= "</div><!-- end oef-home_company_menu -->";
		$data .= "</div><!-- end oef-home_company -->";
		}
	$data .= "</div><!-- end oef-home -->";
	}

$page->SetVar('data', $data);
$page->Display();



?>
