<?php


class Page
	{


	function Page ()
		{
		$this->vars = array('baseurl', 'title', 'data', 'userpane', 'navpane', 'head', 'logo');
		$this->SetVar('baseurl', BASE_URL);
		$this->SetVar('userpane', $this->UserPane());
		}


	function Display ()
		{
		$this->LoadTemplate();
		$this->ParseVars();
		echo $this->templateData;
		}


	function LoadTemplate ()
		{
		$this->templateData = file_get_contents("lib/template.html");
		}


	function ParseVars ()
		{
		if ($_GET['format'] == 'printer')
			{
			$this->vals["userpane"] = null;
			$this->vals["navpane"] = null;
			}
		if ($this->vals["logo"] == null)
			{
			$this->vals["logo"] = LOGO_DEFAULT;
			}
		$this->vals["logo"] = "pics/logos/{$this->vals["logo"]}";
		if ($this->vars != null)
			{
			foreach ($this->vars as $var)
				{
				$this->templateData = str_replace('{$' . $var . '}', $this->vals["{$var}"], $this->templateData);
				}
			}
		}


	function SetVar ($var, $val)
		{
		$this->vals["{$var}"] = $val;
		}


	function Forbidden ($msg = null)
		{
		global $MES;
		if ($msg == null)
			{
			$msg = $MES['access_denied_desc'];
			}
		$this->SetVar('title', $MES['access_denied']);
		$this->SetVar('data', "<div class='oef-forbidden'>{$msg}</div>");
		$this->Display();
		exit;
		}


	function UserPane ()
		{
		global $MES, $user;
		$loggedin = $user->IsLoggedIn();
		if ($loggedin)
			{
			if ($user->first_name != null)
				{
				$name = $user->first_name;
				}
			else
				{
				$name = $user->name;
				}
			$welcomemsg = str_replace('$user', $name, $MES['welcome_user']);
			$logout = " &#187; ";
			$logout .= "<a class='oef-upane_link' href='index.php?do=manage&what=users&op=form&id={$user->id}'>{$MES['edit_personal_details']}</a>";
			$logout .= " | ";
			$logout .= "<a class='oef-upane_link' href='index.php?do=logout'>{$MES['logout']}</a>";
			}
		else
			{
			$welcomemsg = $MES['welcome'];
			}
		$d .= "<div class='oef-upane_container'>";
		$d .= "<div class='oef-upane'>";
		$d .= "<div class='oef-upane_left'>";
		$d .= $welcomemsg . $logout;
		$d .= "</div><!-- end oef-upane_left -->";
		$d .= "<div class='oef-upane_right'>";
		$d .= "<a class='oef-upane_link' href='index.php'>{$MES['home']}</a>";
		if ($loggedin)
			{
			$d .= " | ";
			if ($user->type == 2)
				{
				$d .= "<a class='oef-upane_link' href='index.php?do=manage&what=surveys'>{$MES['manage_surveys']}</a>";
				$d .= " | ";
				}
			$d .= "<a class='oef-upane_link' href='index.php?do=manage&what=users'>{$MES['manage_users']}</a>";
			$d .= " | ";
			$d .= "<a class='oef-upane_link' href='index.php?do=manage&what=reports'>{$MES['manage_reports']}</a>";
			}
		else
			{
			$d .= " | ";
			$d .= "<a class='oef-upane_link' href='index.php?do=login'>{$MES['management']}</a>";
			}
		$d .= "</div><!-- end oef-upane_right -->";
		$d .= "</div><!-- end oef-upane -->";
		$d .= "</div><!-- end oef-upane_container -->";
		return $d;
		}


	function NavPane ($data = null)
		{
		$d .= "<div id='oef-nav' class='oef-nav'>";
		$d .= $data;
		$d .= "</div><!-- end oef-nav -->";
		return $d;
		}


	function AjaxHeaders ()
		{
		header("Expires: Mon, 12 Jul 1982 00:00:00 GMT" );
		header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" );
		header("Cache-Control: no-cache, must-revalidate" );
		header("Pragma: no-cache" );
		}

	}


?>
