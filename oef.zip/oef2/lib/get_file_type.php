<?php


function get_file_type ($file)
	{
    	$fh = fopen($file, "rb");
	$header = fread($fh, 8);
	fclose($fh);
	if (!strncmp ($header, "\xFF\xD8", 2))
		{
		$format = "jpg";
		}
	elseif (!strncmp ($header, "\x89\x50\x4E\x47\x0D\x0A\x1A\x0A", 8))
		{
		$format = "png";
		}
	elseif (!strncmp ($header, "FWS", 3) || !strncmp ($header, "CWS"))
		{
		$format = "swf";
		}
	elseif (!strncmp ($header, "BM", 2))
		{
		$format = "bmp";
		}
	elseif (!strncmp ($header, "\x50\x4b\x03\x04", 4))
		{
		$format = "zip";
		}
	elseif (!strncmp ($header, "GIF", 3))
		{
		$format = "gif";
		}
	else
		{
		$format = null;
		}
	return $format;
	}


?>
