<?php


class Image
	{


	function Image ()
		{
		$this->Name = "";
		}


	function Flag ($cc,$build = null)
		{
		global $CFG;
		class_exists('GeoIP') || require(DIR_LIB . "/class/GeoIP.php");
		$flag =  DIR_FLA . "/" . $cc . ".gif";
		if (file_exists($flag))
			{
			if ($build != null)
				{
				return "<img src='{$flag}' alt='{$cc}' align='absmiddle' onmouseover=\"showCap('" . GeoIP::CountryName($cc) . "');\" onmouseout=\"nd();\" style='cursor:help;'/>";
				}
			else
				{
				return $flag;
				}
			}
		}


	function ChkTyp ($image)
		{
		$mimetype = mime_content_type($image);
		if ($mimetype == 'image/jpeg')
			{
			return "jpg";
			}
		elseif ($mimetype == 'image/gif')
			{
			return "gif";
			}
		elseif ($mimetype == 'image/png')
			{
			return "png";
			}
		}


	function Typ ($t)
		{
		if ($t == 1)
			{
			$type = 'gif';
			}
		elseif ($t == 2)
			{
			$type = 'jpg';
			}
		elseif ($t == 3)
			{
			$type = 'png';
			}
		elseif ($t == 4)
			{
			$type = 'swf';
			}
		elseif ($t == 5)
			{
			$type = 'psd';
			}
		elseif ($t == 6)
			{
			$type = 'bmp';
			}
		/*
		elseif ($t == 7)
			{
			$type = 'gif';
			}
		elseif ($t == 8)
			{
			$type = 'gif';
			}
		elseif ($t == 9)
			{
			$type = 'gif';
			}
		elseif ($t == 10)
			{
			$type = 'gif';
			}
		elseif ($t == 11)
			{
			$type = 'gif';
			}
		elseif ($t == 12)
			{
			$type = 'gif';
			}
		elseif ($t == 13)
			{
			$type = 'gif';
			}
		elseif ($t == 14)
			{
			$type = 'gif';
			}
1 = GIF, 2 = JPG, 3 = PNG, 4 = SWF, 5 = PSD, 6 = BMP, 7 = TIFF(intel byte order), 8 = TIFF(motorola byte order), 9 = JPC, 10 = JP2, 11 = JPX, 12 = JB2, 13 = SWC, 14 = IFF, 15 = WBMP, 16 = XBM
		*/
		return $type;
		}


	function WaterMark ($src)
		{
		global $OPT;


		if (is_resource($src))
			{
			$rtype = @get_resource_type($src);
			}
		else
			{
			$size = @getimagesize($src);
			$truetype = Image::Typ($size[2]);
			}


		if ($rtype == 'gd')
			{
			$srcimg = $src;
			$size = array();
			$size[0] = imagesx($src);
			$size[1] = imagesy($src);
			}
		elseif ($truetype == 'gif')
			{
			$srcimg = imagecreatefromgif($src);
			}
		elseif ($truetype == 'png')
			{
			$srcimg = imagecreatefrompng($src);
			}
		else
			{
			$srcimg = imagecreatefromjpeg($src);
			}


		$im = imagecreatetruecolor($size[0], $size[1]);


		if ($size[2] == IMAGETYPE_GIF || $size[2] == IMAGETYPE_PNG || $rtype == 'gd')
			{
			$trnprt_indx = @imagecolortransparent($srcimg);
			// If we have a specific transparent color
			if ($trnprt_indx >= 0)
				{
				// Get the original image's transparent color's RGB values
				$trnprt_color = @imagecolorsforindex($srcimg, $trnprt_indx);
				// Allocate the same color in the new image resource
				$trnprt_indx = imagecolorallocate($im, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				// Completely fill the background of the new image with allocated color.
				imagefill($im, 0, 0, $trnprt_indx);
				// Set the background color for new image to transparent
				imagecolortransparent($im, $trnprt_indx);
				}
			// Always make a transparent background color for PNGs that don't have one allocated already
			elseif ($size[2] == IMAGETYPE_PNG)
				{
				// Turn off transparency blending (temporarily)
				imagealphablending($im, false);
				// Create a new transparent color for image
				$color = imagecolorallocatealpha($im, 0, 0, 0, 127);
				// Completely fill the background of the new image with allocated color.
				imagefill($im, 0, 0, $color);
				// Restore transparency blending
				imagesavealpha($im, true);
				}
			}


		imagecopyresampled($im, $srcimg, 0, 0, 0, 0, $size[0], $size[1], $size[0], $size[1]);
		$position = $OPT->img_wmp;
		$markfilename = str_replace('DIR_PIC', DIR_PIC, $OPT->img_wmf);
		list($markwidth, $markheight, $marktype) = getimagesize($markfilename);
		$truemarktype = Image::Typ($marktype);
		if ($truemarktype == 'gif')
			{
			$markimage = imagecreatefromgif($markfilename);
			}
		elseif ($truemarktype == 'png')
			{
			$markimage = imagecreatefrompng($markfilename);
			}
		else
			{
			$markimage = imagecreatefromjpeg($markfilename);
			}
		if ($position == '0')
			{
			$xpos = '0';
			$ypos = '0';
			}
		elseif ($position == '1')
			{
			$xpos = $size[0] - $markwidth;
			$ypos = '0';
			}	
		elseif ($position == '2')
			{
			$xpos = '0';
			$ypos = $size[1] - $markheight;
			}
		else
			{
			$xpos = $size[0] - $markwidth;
			$ypos = $size[1] - $markheight;
			}
		imagecopyresampled($im, $markimage, $xpos, $ypos, 0, 0, $markwidth, $markheight, $markheight, $markheight);
		imagedestroy($srcimg);
		imagedestroy($markimage);
		return $im;
		}


	function Resize ($filename, $newwidth = null, $newheight = null, $saveas = null)
		{
		global $OPT;
//exit($filename);

		list($fname,$fext) = explode("\.",$filename);

		$filepath = $filename;
		if (substr($filename, 0, 1) == '/')
			{
			$filepath = BASE . $filename;
			}
		if ($saveas == null && $saveas !== false)
			{
			$saveas = $filepath;
			}


		list($width, $height, $type) = getimagesize($filepath);

		$truetype = Image::Typ($type);

		if (!$newwidth)
			{
			$newwidth = round(($newheight / $height) * $width);
			}
		elseif (!$newheight)
			{
			$newheight = round(($newwidth / $width) * $height);
			}

		//ob_clean();

		if ($truetype == 'jpg')
			{
			//header("Content-type: image/jpeg");
			$im = imagecreatetruecolor($newwidth, $newheight);
			$image = imagecreatefromjpeg($filepath);
			}
		elseif ($truetype == 'gif')
			{
			//header("Content-type: image/gif");
			$im = imagecreate($newwidth, $newheight);
			$image = imagecreatefromgif($filepath);
			}
		elseif ($truetype == 'png')
			{
			//header("Content-type: image/png");
			$im = imagecreatetruecolor($newwidth, $newheight);
			$image = imagecreatefrompng($filepath);
			}


		if ($type == IMAGETYPE_GIF || $type == IMAGETYPE_PNG)
			{
			$trnprt_indx = imagecolortransparent($image);
			// If we have a specific transparent color
			if ($trnprt_indx >= 0)
				{
				// Get the original image's transparent color's RGB values
				$trnprt_color = @imagecolorsforindex($image, $trnprt_indx);
				// Allocate the same color in the new image resource
				$trnprt_indx = imagecolorallocate($im, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				// Completely fill the background of the new image with allocated color.
				imagefill($im, 0, 0, $trnprt_indx);
				// Set the background color for new image to transparent
				imagecolortransparent($im, $trnprt_indx);
				}
			// Always make a transparent background color for PNGs that don't have one allocated already
			elseif ($type == IMAGETYPE_PNG)
				{
				// Turn off transparency blending (temporarily)
				imagealphablending($im, false);
				// Create a new transparent color for image
				$color = imagecolorallocatealpha($im, 0, 0, 0, 127);
				// Completely fill the background of the new image with allocated color.
				imagefill($im, 0, 0, $color);
				// Restore transparency blending
				imagesavealpha($im, true);
				}
			}

//exit("$filename === new w: $newwidth - new h: $newheight ==== w: $width - h: $height");

		imagecopyresampled($im, $image, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

		if ($saveas !== false && $truetype == 'jpg')
			{
			imagejpeg($im, $saveas, $OPT->img_qua);
			}
		elseif ($saveas !== false && $truetype == 'gif')
			{
			imagegif($im, $saveas);
			}
		elseif ($saveas !== false && $truetype == 'png')
			{
			imagepng($im, $saveas);
			}

		// commented out on bicycle day 2010 ---->
		//imagedestroy($im);
		imagedestroy($image);
		return $im;

		}


	function Crop ($src, $x1, $y1, $x2, $y2)
		{
		$newW = $x2 - $x1;
		$newH = $y2 - $y1;
		$oldImg = imagecreatefrompng($src);
		$newImg = ImageCreateTrueColor($newW, $newH);
		list($width, $height, $type) = getimagesize($src);
		if ($type == IMAGETYPE_GIF || $type == IMAGETYPE_PNG)
			{
			$trnprt_indx = imagecolortransparent($oldImg);
			if ($trnprt_indx >= 0)
				{
				// Get the original image's transparent color's RGB values
				$trnprt_color = @imagecolorsforindex($oldImg, $trnprt_indx);
				// Allocate the same color in the new image resource
				$trnprt_indx = imagecolorallocate($newImg, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				// Completely fill the background of the new image with allocated color.
				imagefill($newImg, 0, 0, $trnprt_indx);
				// Set the background color for new image to transparent
				imagecolortransparent($newImg, $trnprt_indx);
				}
			// Always make a transparent background color for PNGs that don't have one allocated already
			elseif ($type == IMAGETYPE_PNG)
				{
				// Turn off transparency blending (temporarily)
				imagealphablending($newImg, false);
				// Create a new transparent color for image
				$color = imagecolorallocatealpha($newImg, 0, 0, 0, 127);
				// Completely fill the background of the new image with allocated color.
				imagefill($newImg, 0, 0, $color);
				// Restore transparency blending
				imagesavealpha($newImg, true);
				}
			}


		imagecopyresampled($newImg, $oldImg, 0, 0, $x1, $y1, $newW, $newH, $newW, $newH);
		imagepng($newImg, $src);
		imagedestroy($oldImg);
		imagedestroy($newImg);
		}


	function RoundCorners ($src, $corsrc = null, $saveas = null, $returnonly = false)
		{
		if ($corsrc == null)
			{
			$corsrc = DIR_PIC . "/corner10.png";
			}

		if (is_resource($src))
			{
			$rtype = @get_resource_type($src);
			}

		$img_corner = imagecreatefrompng($corsrc);
		$corner_width = imagesx($img_corner);
		$corner_height = imagesy($img_corner);
		$corner_radius = $corner_width;

		$img = imagecreatetruecolor($corner_width, $corner_height);


		$size = @getimagesize($src);
		$truetype = Image::Typ($size[2]);
		if ($rtype == 'gd')
			{
			$img = $src;
			$size = array();
			$size[0] = imagesx($src);
			$size[1] = imagesy($src);
			}
		elseif ($truetype == 'gif')
			{
			$img = imagecreatefromgif($src);
			}
		elseif ($truetype == 'png')
			{
			$img = imagecreatefrompng($src);
			}
		else
			{
			$img = imagecreatefromjpeg($src);
			}

		$tmpimg = imagecreatetruecolor($size[0], $size[1]);
		imagecopyresampled($tmpimg, $img, 0, 0, 0, 0, $size[0], $size[1], $size[0], $size[1]);

		$white = ImageColorAllocate($tmpimg, 255, 255, 255);
		$black = ImageColorAllocate($tmpimg, 0, 0 ,0);


		$palette = imagecreatetruecolor($size[0], $size[1]);
		$found = false;
		while($found == false)
			{
			$r = rand(0, 255);
			$g = rand(0, 255);
			$b = rand(0, 255);
			if(imagecolorexact($tmpimg, $r, $g, $b) != (-1))
				{
				$colorcode = imagecolorallocate($palette, $r, $g, $b);
				$red = $r;
				$green = $g;
				$blue = $b;
				$found = true;
				}
			} 

		$index = imagecolorclosest ($img_corner,  255,255,255 );
		imagecolorset($img_corner, $index, $red, $green, $blue);

		$dest_x = 0;
		$dest_y = 0;
		imagecopyresampled($tmpimg, $img_corner, $dest_x, $dest_y, 0, 0, $corner_width, $corner_height, $corner_height, $corner_height);

		$dest_x = 0;
		$dest_y = $size[1] - $corner_height;
		$rotated = imagerotate($img_corner, 90, 0);
		imagecopyresampled($tmpimg, $rotated, $dest_x, $dest_y, 0, 0, $corner_width, $corner_height, $corner_height, $corner_height);

		$dest_x = $size[0] - $corner_width;
		$dest_y = $size[1] - $corner_height;
		$rotated = imagerotate($img_corner, 180, 0);
		imagecopyresampled($tmpimg, $rotated, $dest_x, $dest_y, 0, 0, $corner_width, $corner_height, $corner_height, $corner_height);

		$dest_x = $size[0] - $corner_width;
		$dest_y = 0;
		$rotated = imagerotate($img_corner, 270, 0);
		imagecopyresampled($tmpimg, $rotated, $dest_x, $dest_y, 0, 0, $corner_width, $corner_height, $corner_height, $corner_height);


		imagecolortransparent($tmpimg, $colorcode);


		if ($saveas != null)
			{
			$saveto = $saveas;
			imagepng($tmpimg, $saveto);
			}
		elseif (!$returnonly && $rtype != 'gd')
			{
			header("Content-type: image/png");
			imagepng($tmpimg);
			}


		imagedestroy($img);
		//imagedestroy($tmpimg);
		imagedestroy($img_corner);
		imagedestroy($palette);
		return $tmpimg;
		}


	function ConvertToPng ($src, $saveas = null)
		{
//exit("$src === $saveas");
		$srcpath = $src;
		if (substr($src, 0, 1) == '/')
			{
			$srcpath = BASE . $src;
			}
		list($width, $height, $type) = getimagesize($srcpath);
		$truetype = Image::Typ($type);
		$image = imagecreatetruecolor($width, $height);
		if ($truetype == 'gif')
			{
			$img = imagecreatefromgif($srcpath);
			}
		elseif ($truetype == 'png')
			{
			$img = imagecreatefrompng($srcpath);
			}
		else
			{
			$img = imagecreatefromjpeg($srcpath);
			}


		if ($type == IMAGETYPE_GIF || $type == IMAGETYPE_PNG)
			{
			$trnprt_indx = imagecolortransparent($img);
			// If we have a specific transparent color
			if ($trnprt_indx >= 0)
				{
				// Get the original image's transparent color's RGB values
				$trnprt_color = @imagecolorsforindex($img, $trnprt_indx);
				// Allocate the same color in the new image resource
				$trnprt_indx = imagecolorallocate($image, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				// Completely fill the background of the new image with allocated color.
				imagefill($image, 0, 0, $trnprt_indx);
				// Set the background color for new image to transparent
				imagecolortransparent($image, $trnprt_indx);
				}
			// Always make a transparent background color for PNGs that don't have one allocated already
			elseif ($type == IMAGETYPE_PNG)
				{
				// Turn off transparency blending (temporarily)
				imagealphablending($image, false);
				// Create a new transparent color for image
				$color = imagecolorallocatealpha($image, 0, 0, 0, 127);
				// Completely fill the background of the new image with allocated color.
				imagefill($image, 0, 0, $color);
				// Restore transparency blending
				imagesavealpha($image, true);
				}
			}



		imagecopyresampled($image, $img, 0, 0, 0, 0, $width, $height, $width, $height);
		if ($saveas != null)
			{
			$saveto = $saveas;
			}
		else
			{
			$saveto = str_ireplace(array(".jpg", ".jpeg", ".gif", ".png"), "", $src) . ".png";
			} 
		imagepng($image, $saveto);
		imagedestroy($image);
		imagedestroy($img);
		}


	}


?>
