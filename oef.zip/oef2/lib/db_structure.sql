-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 20, 2010 at 01:58 PM
-- Server version: 5.0.32
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oef`
--

-- --------------------------------------------------------

--
-- Table structure for table `oef_averages`
--

CREATE TABLE IF NOT EXISTS `oef_averages` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `user` int(10) NOT NULL default '0',
  `all` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `oef_averages`
--


-- --------------------------------------------------------

--
-- Table structure for table `oef_evaluations`
--

CREATE TABLE IF NOT EXISTS `oef_evaluations` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `eid` int(10) NOT NULL default '0',
  `ip` varchar(15) character set utf8 collate utf8_unicode_ci NOT NULL,
  `assessed` int(10) NOT NULL default '0',
  `title` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `department` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `manager` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam` tinyint(1) NOT NULL default '0',
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `oef_evaluations`
--


-- --------------------------------------------------------

--
-- Table structure for table `oef_sessions`
--

CREATE TABLE IF NOT EXISTS `oef_sessions` (
  `id` int(15) NOT NULL auto_increment,
  `ip` varchar(15) character set utf8 collate utf8_unicode_ci NOT NULL,
  `host` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `itime` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`),
  KEY `name` (`name`),
  KEY `itime` (`itime`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `oef_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `oef_surveys`
--

CREATE TABLE IF NOT EXISTS `oef_surveys` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `competencies` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `created` int(10) NOT NULL default '0',
  `partner` int(10) NOT NULL default '0',
  `visible` int(1) NOT NULL default '1',
  `type` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `oef_surveys`
--

INSERT INTO `oef_surveys` (`id`, `name`, `competencies`, `questions`, `writeins`, `created`, `partner`, `visible`, `type`) VALUES
(1, 'Tamayyaz Survey', '1|Impact\n2|Influence\n3|Communication\n4|Integrity and Trust\n5|Customer Focus\n6|Team Working\n7|Organization\n8|Drive\n9|Problem Solving', '1|Stimulates high achievement\n1|Inspires trust\n1|Creates commitment\n1|Treats people fairly\n1|Resolves conflicts in a constructive manner\n2|Keeps relevant parties informed and up to date\n2|Develops networks\n2|Shares expertise and information willingly\n2|Gains cooperation from others\n2|Demonstrates self-confidence\n3|Has good listening skills\n3|Questions others\n3|Is an articulate verbal communicator\n3|Can communicate in writing effectively\n3|Demonstrates positive body language\n4|Presents truthful information in an appropriate and helpful manner\n4|Consistently applies personal values to appropriately address difficult situations\n4|Stays true to his or her values, regardless of internal and external pressures\n4|Is definitely trusted to keep confidences and to protect sensitive information, even to his or her own detriment\n5|Commits to meeting the expectations and requirements of internal and external customers\n5|Builds and maintains effective relationships with clients, gains their trust and respect and finds out ways to improve services\n5|Strategically plans ways to demonstrate superior customer service \n5|Foresee clients'' future needs\n5|Coach employees toward gaining clients'' trust and respect for the organization\n6|Inspires extra effort\n6|Provides public recognition of team member contributions\n6|Creates a strong team identity\n6|Establishes the need for collaboration\n6|Empowers team members\n6|Sets challenging but realistic goals\n7|Develops specific action plans\n7|Organizes work efficiently\n7|Implements high work standards\n7|Monitors output\n8|Accepts responsibilities for outcome of decisions\n8|Takes steps to avoid obstacles\n8|Is focused on results\n8|Manages change\n8|Deters deviations from plans\n9|Distinguishes between relevant and irrelevant information easily\n9|Identifies patterns or relationships from information and events\n9|Uses concepts or models to analyse situations\n9|Develops creative solutions to problems\n9|Seeks information from a variety of sources', 'What are the most important (1-3) things this person should START DOING to increase his/her effectiveness as a teammate?\nWhat are the most important (1-3) things this person should STOP DOING as they limit his/her effectiveness as a teammate?\nWhat are the most important (1-3) things this person should CONTINUE DOING to maintain his/her greatest strengths as a teammate?', 1268482266, 8, 1, 0),
(2, 'Employee Satisfaction Survey', '1|Feedback\n2|Opportunities for Growth\n3|Teamwork\n4|Work/Life Balance; Stress and Work Pace\n5|Quality and Customer Focus\n6|Fairness\n7|Mission and Purpose\n8|Respect for Management\n9|Compensation\n10|Respect for Employees\n11|Workplace and Resources\n12|Personal Expression/ Diversity\n13|Communication', '1|I receive useful and constructive feedback from my manager.\n1|I am given adequate feedback about my performance.\n1|I receive feedback that helps me improve my performance.\n1|I have an opportunity to participate in the goal setting process.\n1|Employee performance evaluations are fair and appropriate.\n1|My supervisor gives me praise and recognition when I do a good job.\n1|When I do a good job, I receive the praise and recognition I deserve.\n2|I have adequate opportunities for professional growth in this organization.\n2|I receive the training I need to do my job well.\n2|My manager is actively interested in my professional development and advancement.\n2|My manager encourages and supports my development.\n2|I am encouraged to learn from my mistakes.\n2|My work is challenging.\n2|My work is stimulating.\n2|My work is rewarding.\n2|I have a mentor at work.\n3|Teamwork is encouraged and practiced in this organization.\n3|There is a strong feeling of teamwork and cooperation in this organization.\n4|The environment in this organization supports a balance between work and personal life.\n4|My manager understands the importance of maintaining a balance between work and personal life.\n4|I am able to satisfy both my job and family responsibilities.\n4|I am not forced to choose between job and family obligations.\n4|The pace of the work in this organization enables me to do a good job.\n4|The amount of work I am asked to do is reasonable.\n4|The organization has reasonable expectations of its employees.\n4|My job does not cause unreasonable amounts of stress in my life.\n5|People are held accountable for the quality of work they produce.\n5|The quality of our products and services are very important to this organization.\n5|In this organization we maintain very high standards of quality.\n5|This organization understands its customers'' needs.\n5|This organization is extremely focused on its customers'' needs.\n5|Customer needs are the top priority in this organization.\n6|My manager treats all his/her employees fairly.\n6|The organization''s policies for promotion and advancement are always fair.\n6|Favoritism (special treatment) is not an issue in raises or promotions.\n6|My manager is always consistent when administering policies concerning employees.\n6|I am always treated fairly by my manager.\n6|Everybody is treated fairly in this organization.\n7|I have a good understanding of the mission and the goals of this organization.\n7|I understand how my work directly contributes to the overall success of the organization.\n7|My job is important in accomplishing the mission of the organization.\n7|My supervisor provides me regular information about the mission and the goals of this organization.\n7|I am familiar with and understand the organization''s strategic goals.\n7|Doing my job well gives me a sense of personal satisfaction.\n8|I respect the senior leaders of this organization.\n8|I respect my manager as a competent professional.\n8|The leaders of this organization know what they are doing.\n8|Our senior managers demonstrate strong leadership skills.\n8|I am very satisfied with my manager.\n9|I am paid fairly for the work I do.\n9|My salary is competitive with similar jobs I might find elsewhere.\n9|My benefits are comparable to those offered by other organizations.\n9|I understand my benefit plan.\n9|I am satisfied with my benefit package.\n10|My manager always treats me with respect.\n10|My manager listens to what I''m saying.\n10|This organization respects its employees.\n10|My manager values my talents and the contribution I make.\n10|My talent is valued at work.\n10|The organization values the contribution I make.\n10|My coworkers care about me as a person.\n11|I have the resources I need to do my job well.\n11|The necessary information systems are in place and accessible for me to get my job done.\n11|I have all the information I need to do my job effectively.\n11|My workplace is well maintained.\n11|My workplace is a physically comfortable place to work.\n11|My workplace is safe.\n12|People who challenge the status quo are valued.\n12|I can disagree with my supervisor without fear of getting in trouble.\n12|I am comfortable sharing my opinions at work.\n12|We work to attract, develop, and retain people with diverse backgrounds.\n12|People with different ideas are valued in this organization.\n12|My ideas and opinions count at work.\n13|Information and knowledge are shared openly within this organization.\n13|Communication is encouraged in this organization.\n13|My manager does a good job of sharing information.\n13|Senior management communicates well with the rest of the organization.', 'Please share any additional thoughts you have:', 1275823603, 2, 1, 2),
(3, 'Customer Satisfaction Survey', '1|Feedback\n2|Opportunities for Growth\n3|Teamwork\n4|Work/Life Balance; Stress and Work Pace\n5|Quality and Customer Focus\n6|Fairness\n7|Mission and Purpose\n8|Respect for Management\n9|Compensation\n10|Respect for Employees\n11|Workplace and Resources\n12|Personal Expression/ Diversity\n13|Communication', '1|I receive useful and constructive feedback from my manager.\n1|I am given adequate feedback about my performance.\n1|I receive feedback that helps me improve my performance.\n1|I have an opportunity to participate in the goal setting process.\n1|Employee performance evaluations are fair and appropriate.\n1|My supervisor gives me praise and recognition when I do a good job.\n1|When I do a good job, I receive the praise and recognition I deserve.\n2|I have adequate opportunities for professional growth in this organization.\n2|I receive the training I need to do my job well.\n2|My manager is actively interested in my professional development and advancement.\n2|My manager encourages and supports my development.\n2|I am encouraged to learn from my mistakes.\n2|My work is challenging.\n2|My work is stimulating.\n2|My work is rewarding.\n2|I have a mentor at work.\n3|Teamwork is encouraged and practiced in this organization.\n3|There is a strong feeling of teamwork and cooperation in this organization.\n4|The environment in this organization supports a balance between work and personal life.\n4|My manager understands the importance of maintaining a balance between work and personal life.\n4|I am able to satisfy both my job and family responsibilities.\n4|I am not forced to choose between job and family obligations.\n4|The pace of the work in this organization enables me to do a good job.\n4|The amount of work I am asked to do is reasonable.\n4|The organization has reasonable expectations of its employees.\n4|My job does not cause unreasonable amounts of stress in my life.\n5|People are held accountable for the quality of work they produce.\n5|The quality of our products and services are very important to this organization.\n5|In this organization we maintain very high standards of quality.\n5|This organization understands its customers'' needs.\n5|This organization is extremely focused on its customers'' needs.\n5|Customer needs are the top priority in this organization.\n6|My manager treats all his/her employees fairly.\n6|The organization''s policies for promotion and advancement are always fair.\n6|Favoritism (special treatment) is not an issue in raises or promotions.\n6|My manager is always consistent when administering policies concerning employees.\n6|I am always treated fairly by my manager.\n6|Everybody is treated fairly in this organization.\n7|I have a good understanding of the mission and the goals of this organization.\n7|I understand how my work directly contributes to the overall success of the organization.\n7|My job is important in accomplishing the mission of the organization.\n7|My supervisor provides me regular information about the mission and the goals of this organization.\n7|I am familiar with and understand the organization''s strategic goals.\n7|Doing my job well gives me a sense of personal satisfaction.\n8|I respect the senior leaders of this organization.\n8|I respect my manager as a competent professional.\n8|The leaders of this organization know what they are doing.\n8|Our senior managers demonstrate strong leadership skills.\n8|I am very satisfied with my manager.\n9|I am paid fairly for the work I do.\n9|My salary is competitive with similar jobs I might find elsewhere.\n9|My benefits are comparable to those offered by other organizations.\n9|I understand my benefit plan.\n9|I am satisfied with my benefit package.\n10|My manager always treats me with respect.\n10|My manager listens to what I''m saying.\n10|This organization respects its employees.\n10|My manager values my talents and the contribution I make.\n10|My talent is valued at work.\n10|The organization values the contribution I make.\n10|My coworkers care about me as a person.\n11|I have the resources I need to do my job well.\n11|The necessary information systems are in place and accessible for me to get my job done.\n11|I have all the information I need to do my job effectively.\n11|My workplace is well maintained.\n11|My workplace is a physically comfortable place to work.\n11|My workplace is safe.\n12|People who challenge the status quo are valued.\n12|I can disagree with my supervisor without fear of getting in trouble.\n12|I am comfortable sharing my opinions at work.\n12|We work to attract, develop, and retain people with diverse backgrounds.\n12|People with different ideas are valued in this organization.\n12|My ideas and opinions count at work.\n13|Information and knowledge are shared openly within this organization.\n13|Communication is encouraged in this organization.\n13|My manager does a good job of sharing information.\n13|Senior management communicates well with the rest of the organization.', 'Please share any additional thoughts you have:', 1275898696, 2, 1, 1),
(4, 'Formatech Survey', '1|Overall\n2|Opportunities for Growth\n3|Teamwork\n4|Work/Life Balance; Stress and Work Pace\n5|Quality and Customer Focus\n6|Mission and Purpose\n7|Respect for Management\n8|Compensation\n9|Respect for Employees\n10|Workplace and Resources\n11|Personal Expression/ Diversity\n12|Communication', '1|Overall, how would you like\n1|I am given adequate feedback about my performance.\n1|I receive feedback that helps me improve my performance.\n1|I have an opportunity to participate in the goal setting process.\n1|Employee performance evaluations are fair and appropriate.\n2|I have adequate opportunities for professional growth in this organization.\n2|I receive the training I need to do my job well.\n2|My manager is actively interested in my professional development and advancement.\n2|My manager encourages and supports my development.\n2|I am encouraged to learn from my mistakes.\n2|My work is challenging.\n2|My work is stimulating.\n2|My work is rewarding.\n2|I have a mentor at work.\n3|Teamwork is encouraged and practiced in this organization.\n3|There is a strong feeling of teamwork and cooperation in this organization.\n4|The environment in this organization supports a balance between work and personal life.\n4|My manager understands the importance of maintaining a balance between work and personal life.\n4|I am able to satisfy both my job and family responsibilities.\n4|I am not forced to choose between job and family obligations.\n4|The pace of the work in this organization enables me to do a good job.\n4|The amount of work I am asked to do is reasonable.\n4|The organization has reasonable expectations of its employees.\n4|My job does not cause unreasonable amounts of stress in my life.\n5|People are held accountable for the quality of work they produce.\n5|The quality of our products and services are very important to this organization.\n5|In this organization we maintain very high standards of quality.\n5|This organization understands its customers'' needs.\n5|This organization is extremely focused on its customers'' needs.\n5|Customer needs are the top priority in this organization.\n6|I have a good understanding of the mission and the goals of this organization.\n6|I understand how my work directly contributes to the overall success of the organization.\n6|My job is important in accomplishing the mission of the organization.\n6|My supervisor provides me regular information about the mission and the goals of this organization.\n6|I am familiar with and understand the organization''s strategic goals.\n6|Doing my job well gives me a sense of personal satisfaction.\n7|I respect the senior leaders of this organization.\n7|I respect my manager as a competent professional.\n7|The leaders of this organization know what they are doing.\n7|Our senior managers demonstrate strong leadership skills.\n7|I am very satisfied with my manager.\n8|I am paid fairly for the work I do.\n8|My salary is competitive with similar jobs I might find elsewhere.\n8|My benefits are comparable to those offered by other organizations.\n8|I understand my benefit plan.\n8|I am satisfied with my benefit package.\n9|My manager always treats me with respect.\n9|My manager listens to what I''m saying.\n9|This organization respects its employees.\n9|My manager values my talents and the contribution I make.\n9|My talent is valued at work.\n9|The organization values the contribution I make.\n9|My coworkers care about me as a person.\n10|I have the resources I need to do my job well.\n10|The necessary information systems are in place and accessible for me to get my job done.\n10|I have all the information I need to do my job effectively.\n10|My workplace is well maintained.\n10|My workplace is a physically comfortable place to work.\n10|My workplace is safe.\n11|People who challenge the status quo are valued.\n11|I can disagree with my supervisor without fear of getting in trouble.\n11|I am comfortable sharing my opinions at work.\n11|We work to attract, develop, and retain people with diverse backgrounds.\n11|People with different ideas are valued in this organization.\n11|My ideas and opinions count at work.\n12|Information and knowledge are shared openly within this organization.\n12|Communication is encouraged in this organization.\n12|My manager does a good job of sharing information.\n12|Senior management communicates well with the rest of the organization.', 'how could formatech....\nSecond text box Q', 1277276885, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oef_users`
--

CREATE TABLE IF NOT EXISTS `oef_users` (
  `id` int(10) NOT NULL auto_increment,
  `creator` int(10) NOT NULL default '0',
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  `type` int(2) NOT NULL default '0',
  `company` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `eac` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ea` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `oef_users`
--

INSERT INTO `oef_users` (`id`, `creator`, `name`, `first_name`, `last_name`, `email`, `password`, `type`, `company`, `eac`, `ea`) VALUES
(1, 0, 'admin', 'John', 'Doe', 'admin@example.com', '1a1dc91c907325c69271ddf0c944bc72', 2, '', '', '');
