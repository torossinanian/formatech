<?php


class Survey
	{


	function Survey ($id = null)
		{
		if ($id != null)
			{
			$this->id = $id;
			$this->GetData();
			}
		}


	function GetArray ()
		{
		$this->allArray = array();
		$q = "SELECT `id`, `name` FROM `" . TBLPRE . "surveys` ORDER BY `name` ASC";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				$this->allArray["{$r['id']}"] = $r['name'];
				}
			}
		}


	function GetEvaluation ()
		{
		$q = "SELECT * FROM `" . TBLPRE . "evaluations` WHERE `id` = '" . DB::Escape($this->eid) . "' LIMIT 1";
		$res = DB::Query($q);
		$this->evaluation = array();
		if (@mysql_num_rows($res) > 0)
			{
			$r = mysql_fetch_array($res, MYSQL_ASSOC);
			foreach ($r as $r_i => $r_v)
				{
				$this->evaluation["{$r_i}"] = $r_v;
				}
			$qCount = 1;
			$queArray = explode("\n", $this->evaluation['questions']);
			foreach ($queArray as $q)
				{
				$this->evaluation['ques']["{$qCount}"] = trim($q);
				$qCount++;
				}
			$wCount = 1;
			$winArray = explode("\n", $this->evaluation['writeins']);
			foreach ($winArray as $w)
				{
				$this->evaluation['wins']["{$wCount}"] = trim($w);
				$wCount++;
				}
			}
		if ($this->evaluation["eid"] > 0)
			{
			$this->euser = new User($this->evaluation['eid']);
			}
		if ($this->evaluation["assessed"] > 0)
			{
			$this->auser = new User($this->evaluation['assessed']);
			}
		}


	function GetData ()
		{
		$q = "SELECT * FROM `" . TBLPRE . "surveys` WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			$record = mysql_fetch_array($res, MYSQL_ASSOC);
			foreach ($record as $r_i => $r_v)
				{
				$this->$r_i = $r_v;
				}
			if ($this->competencies != null)
				{
				$this->comArray = explode("\n", $this->competencies);
				$this->comCount = count($this->comArray);
				$this->coms = array();
				foreach ($this->comArray as $c)
					{
					list($c_i, $c_v) = explode("|", $c);
					$this->coms["{$c_i}"] = $c_v;
					}
				}
			if ($this->questions != null)
				{
				$this->queArray = explode("\n", $this->questions);
				$this->queCount = count($this->queArray);
				$this->ques = array();
				foreach ($this->queArray as $q)
					{
					list($q_i, $q_v) = explode("|", $q);
					$this->ques["{$q_i}"][] = $q_v;
					}
				}
			if ($this->writeins != null)
				{
				$this->winArray = explode("\n", $this->writeins);
				$this->winCount = count($this->winArray);
				$this->wins = array();
				foreach ($this->winArray as $w)
					{
					$this->wins[] = $w;
					}
				}
			}
		}


	function ProcessResults ()
		{
		for ($i = 1; $i <= $this->queCount; $i++)
			{
			$questions .= $_POST["q-{$i}"] . "\n";
			}
		for ($i = 1; $i <= $this->winCount; $i++)
			{
			$writeins .= str_replace("\n", "<br/>", $_POST["w-{$i}"]) . "\n";
			}
		$questions = rtrim($questions);
		$writeins = rtrim($writeins);
		$q = "INSERT INTO `" . TBLPRE . "evaluations` (`survey`, `eid`, `assessed`, `iam`, `questions`, `writeins`, `time`) VALUES(";
		$q .= "'" . DB::Escape($this->id) . "', ";
		$q .= "'" . DB::Escape($_GET['eid']) . "', ";
		$q .= "'" . DB::Escape($_POST['assessed']) . "', ";
		//$q .= "'" . DB::Escape($_POST['title']) . "', ";
		//$q .= "'" . DB::Escape($_POST['department']) . "', ";
		//$q .= "'" . DB::Escape($_POST['manager']) . "', ";
		$q .= "'" . DB::Escape($_POST['iam']) . "', ";
		$q .= "'" . DB::Escape($questions) . "', ";
		$q .= "'" . DB::Escape($writeins) . "', ";
		$q .= "'" . DB::Escape(time()) . "'";
		$q .= ")";
		DB::Query($q);
		$eid = mysql_insert_id();
		$this->NotifyAdmins($eid);
		return $eid;
		}


	function NotifyAdmins ($eid)
		{
		global $MES;
		$emldat = file_get_contents("lib/evaluated_email.txt");
		$partner = new User($this->partner);
		$q = "SELECT `name`, `email`, `first_name`, `last_name` FROM `" . TBLPRE . "users` WHERE `type` = '2'";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				$f = array(
					'{$name}',
					'{$loginurl}',
					'{$evaluationurl}'
					);
				if ($r['first_name'] != null || $r['last_name'] != null)
					{
					$name = $r['first_name'] . " " . $r['last_name'];
					}
				else
					{
					$name = $r['name'];
					}
				$r = array(
					trim($name),
					BASE_URL . "/index.php?do=login",
					BASE_URL . "/index.php?id={$this->id}&evaluation={$eid}"
					);
				$emldat = str_replace($f, $r, $emldat);
				$to = str_replace("\n","",$this->email);
				$to = str_replace("\r","",$to);
				$subject = str_replace(array("\n", '$company'), array("", $partner->company),$MES['evaluation_subject']);
				$subject = str_replace("\r","",$subject);
				$from_name = str_replace("\n","",$MES['partner_from_name']);
				$from_name = str_replace("\r","",$from_name);
				$from_email = str_replace("\n","",$MES['partner_from_email']);
				$from_email = str_replace("\r","",$from_email);
				$headers  = "MIME-Version: 1.0\r\n";
				$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
				$headers .= "X-Priority: 3\r\n";
				$headers .= "X-MSMail-Priority: Normal\r\n";
				$headers .= "X-Mailer: MailQ / PHP\r\n";
				$headers .= "From: \"$from_name\" <$from_email>\r\n";
				mail($to, $subject, $emldat, $headers);
				}
			}
		}


	function Make ()
		{
		global $MES, $page;
		$showform = true;
		$this->hasAssignedUsers = false;
		if ($_GET['eid'])
			{
			$this->euser = new User($_GET['eid']);
			}
		if ($_POST['process'] == 'y')
			{
			$showform = false;
			$q = "SELECT `assessed` FROM `" . TBLPRE . "evaluations` WHERE `survey` = '" . DB::Escape($this->id) . "' && `eid` = '" . DB::Escape($this->euser->id) . "' && `assessed` = '" . DB::Escape($_POST['assessed']) . "' LIMIT 1";
			$res = DB::Query($q);
			if ($this->type == 2 && @mysql_num_rows($res) > 0)
				{
				$d .= $MES['only_evaluate_once'];
				}
			else
				{
				$this->ProcessResults();
				$d .= str_replace('$company', $this->cuser->company, $MES['evaluation_thanks']);
				}
			}
		if ($showform)
			{

			$langMessages .= "<script type=\"text/javascript\">\n";
			$langMessages .= "langMes['name'] = \"{$MES['your_name']}\";\n";
			$langMessages .= "langMes['assessed'] = \"{$MES['employee_assessed']}\";\n";
			$langMessages .= "langMes['title'] = \"{$MES['title']}\";\n";
			$langMessages .= "langMes['department'] = \"{$MES['department']}\";\n";
			//$langMessages .= "langMes['manager'] = \"{$MES['manager']}\";\n";
			$langMessages .= "langMes['iam'] = \"{$MES['i_am_their']}\";\n";
			$langMessages .= "langMes['behavior'] = \"{$MES['behavior']}\";\n";
			$langMessages .= "langMes['missing_notice'] = \"{$MES['missing_field_notice']}\";\n";
			$langMessages .= "langMes['missing_fields'] = \"{$MES['missing_fields']}\";\n";
			$wcount = 1;
			foreach ($this->wins as $w)
				{
				$langMessages .= "langMes['writein-{$wcount}'] = \"{$w}\";\n";
				$wcount++;
				}
			$langMessages .= "</script>\n";
			$page->SetVar('head', $langMessages);

			// background info
			$d .= "<form name='oef-survey-form' id='oef-survey-form' method='POST' action='{$_SERVER['REQUEST_URI']}' onsubmit=\"return checkForMissing();\">";
			$d .= "<input type='hidden' name='queCount' value='{$this->queCount}'/>";
			$d .= "<input type='hidden' name='winCount' value='{$this->winCount}'/>";
			$d .= "<input type='hidden' name='process' value='y'/>";
			$d .= $this->Background();
			// instructions
			if ($this->evaluation == null)
				{
				$d .= $this->Instructions();
				}
			// the survey heading
			$d .= $this->MakeQuestionGroupLayout(3, $MES['competencies'], $this->MakeQuestionTable(3, $MES['behaviors'], $MES['rating']));
			// the ratings heading
			$d .= $this->MakeQuestionGroupLayout(2, null, $this->MakeQuestionTable(2, null, 1, 2, 3, 4, 5, $MES['not_applicable']));
			$this->cqid = 0;
			if ($this->coms != null)
				{
				foreach ($this->coms as $c_i => $c_v)
					{
					$d .= $this->MakeQuestionGroup($c_i);
					}
				}
			$d .= $this->WriteInFields();
			if ($this->evaluation == null)
				{
				$d .= "<div class='oef-survey_submit'>";
				$d .= "<input type='submit' class='oef-survey_submit_button' value=\"" . htmlspecialchars($MES['send_evaluation']) . "\"/>";
				$d .= "</div><!-- end oef-survey_submit -->";
				}
			$d .= "</form>";
			if (false && $this->type == 2 && !$this->hasAssignedUsers)
				{
				$d = $MES['no_one_to_evaluate'];
				}
			}
		return "<div class='oef-survey'>" . $d . "</div><!-- end oef-survey -->";
		}


	function MakeQuestionGroup ($gid)
		{
		//global $MES;
		if ($this->ques["{$gid}"] != null)
			{
			$ga = $this->ques["{$gid}"];
			$qcount = 0;
			foreach ($ga as $q)
				{
				$qcount++;
				$this->cqid++;
				$questions .= $this->MakeQuestion($this->cqid, $q); //"{$gid}-{$qcount}"
				}
			}
		$d = $this->MakeQuestionGroupLayout(1, $this->coms["{$gid}"], $questions);
		return $d;
		}

	/* modes:
		1 = normal (populate a question with radio fields)
		2 = rating head
		3 = survey head
	*/
	function MakeQuestionGroupLayout ($mode = 1, $name = null, $questions = null)
		{
		if ($mode == 3)
			{
			$class = 'oef-qgroup_survey';
			$nclass = 'oef-qgroup_name_head';
			}
		elseif ($mode == 2)
			{
			$class = 'oef-qgroup_rating';
			$nclass = 'oef-qgroup_name_head';
			}
		else
			{
			$class = 'oef-qgroup';
			$nclass = 'oef-qgroup_name';
			}
		$d .= "<div class='{$class}'>";
		$d .= "<div class='{$nclass}'>{$name}</div><!-- end oef-qgroup_name -->";
		$d .= "<div class='oef-qgroup_questions'>{$questions}</div><!-- end oef-qgroup_name -->";
		$d .= "</div><!-- end oef-qgroup -->";
		return $d;
		}


	function MakeQuestion ($qid, $qval)
		{
		if ($this->evaluation['ques']["{$qid}"] == 1)
			{
			$op1sel = " checked='checked'";
			}
		elseif ($this->evaluation['ques']["{$qid}"] == 2)
			{
			$op2sel = " checked='checked'";
			}
		elseif ($this->evaluation['ques']["{$qid}"] == 3)
			{
			$op3sel = " checked='checked'";
			}
		elseif ($this->evaluation['ques']["{$qid}"] == 4)
			{
			$op4sel = " checked='checked'";
			}
		elseif ($this->evaluation['ques']["{$qid}"] == 5)
			{
			$op5sel = " checked='checked'";
			}
		elseif ($this->evaluation['ques']["{$qid}"] == 0)
			{
			$op0sel = " checked='checked'";
			}
		$d = $this->MakeQuestionTable(
		1,
		$qid . ". " . $qval,
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='1'{$op1sel}/>",
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='2'{$op2sel}/>",
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='3'{$op3sel}/>",
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='4'{$op4sel}/>",
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='5'{$op5sel}/>",
		"<input type='radio' class='oef-question_input_select' name='q-{$qid}' value='0'{$op0sel}/>"
		);
		return $d;
		}


	/* modes:
		1 = normal (populate a question with radio fields)
		2 = rating head
		3 = survey head
	*/
	function MakeQuestionTable ($mode = 1, $f1 = null, $f2 = null, $f3 = null, $f4 = null, $f5 = null, $f6 = null, $f7 = null)
		{
		if ($mode == 1)
			{
			$tblclass = 'oef-question_tbl';
			$tclass = 'oef-question_tbl_text';
			$baseclass = 'oef-question_tbl_opt';
			}
		elseif ($mode == 2)
			{
			$tblclass = 'oef-question_tbl_head';
			$tclass = 'oef-question_tbl_text';
			$baseclass = 'oef-question_tbl_opt';
			}
		elseif ($mode == 3)
			{
			$tblclass = 'oef-question_tbl_head';
			$tclass = 'oef-question_tbl_text_head';
			}
		$d .= "<table class='{$tblclass}'>";
		$d .= "<tr>";
		$d .= "<td class='{$tclass}'>{$f1}</td>";
		if ($mode == 3)
			{
			$d .= "<td class='oef-question_ratings'>{$f2}</td>";
			}
		else
			{
			$d .= "<td class='{$baseclass} {$baseclass}1'>{$f2}</td>";
			$d .= "<td class='{$baseclass} {$baseclass}2'>{$f3}</td>";
			$d .= "<td class='{$baseclass} {$baseclass}3'>{$f4}</td>";
			$d .= "<td class='{$baseclass} {$baseclass}4'>{$f5}</td>";
			$d .= "<td class='{$baseclass} {$baseclass}5'>{$f6}</td>";
			$d .= "<td class='{$baseclass} {$baseclass}0'>{$f7}</td>";
			}
		$d .= "</tr>";
		$d .= "</table>";
		return $d;
		}


	function Instructions ()
		{
		global $MES;
		$d .= "<div class='oef-instr'>";
		$d .= "<div class='oef-instr_head'>";
		$d .= $MES['instructions'];
		$d .= "</div><!-- end oef-instr_head -->";
		$d .= "<div class='oef-intro'>";
		$d .= $MES['intro'];
		$d .= "</div><!-- end oef-intro -->";
		$d .= "<div class='oef-truth'>";
		$d .= "<div class='oef-truth_head'>";
		$d .= $MES['be_truthful'];
		$d .= "</div><!-- end oef-truth_head -->";
		$d .= $MES['be_truthful_desc'];
		$d .= "</div><!-- end oef-truth -->";
		$d .= "<div class='oef-conf'>";
		$d .= "<div class='oef-conf_head'>";
		$d .= $MES['confidentiality'];
		$d .= "</div><!-- end oef-conf_head -->";
		$d .= $MES['confidentiality_desc'];
		$d .= "</div><!-- end oef-conf -->";

		$d .= "<div class='oef-numq'>";
		$d .= "<div class='oef-numq_head'>";
		$d .= $MES['numerical_questions'];
		$d .= "</div><!-- end oef-numq_head -->";
		$d .= $MES['please_indicate'];
		$d .= "<ul class='oef-numq_list'>";
		for ($i = 1; $i <= 5; $i++)
			{
			$d .= "<li class='oef-numq_li'><span class='oef-numq_num'>{$i}</span> = " . $MES["opt{$i}"] . "</li>";
			}
		$d .= "</ul>";
		$d .= $MES['simply_tick'];
		$d .= "</div><!-- end oef-numq -->";

		$d .= "<div class='oef-com'>";
		$d .= "<div class='oef-com_head'>";
		$d .= $MES['comments'];
		$d .= "</div><!-- end oef-com_head -->";
		$d .= $MES['comments_desc'];
		$d .= "</div><!-- end oef-com -->";

		$d .= "</div><!-- end oef-instr -->";
		return $d;
		}


	function GetCompanyUsers ()
		{
		$this->companyusers = array();
		$q = "SELECT `id`, `first_name`, `last_name` FROM `" . TBLPRE . "users` WHERE `type` = '0' && `creator` = '" . DB::Escape($this->partner) . "' ORDER BY `first_name`, `last_name`";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				$this->companyusers["{$r['id']}"] = $r['first_name'] . " " . $r['last_name'];
				}
			}
		}


	function Background ()
		{
		global $MES;
		$d .= "<div class='oef-bginfo'>";

		$d .= "<table class='oef-bginfo_tbl'>";

		if ($this->euser->ea != null)
			{
			$eaArray = explode(",", $this->euser->ea);
			// get the names of people this employee may evaluate
			$q = "SELECT `id`, `first_name`, `last_name` FROM `" . TBLPRE . "users` WHERE";
			foreach ($eaArray as $e)
				{
				$cond .= " `id` = '" . DB::Escape($e) . "' || ";
				}
			$q .= rtrim($cond, " |");
			$res = DB::Query($q);
			while ($r = mysql_fetch_array($res))
				{
				$eNames["{$r['id']}"] = "{$r['first_name']} {$r['last_name']}";
				}
			// determine who this employee has already evaluated
			$q = "SELECT `assessed` FROM `" . TBLPRE . "evaluations` WHERE `survey` = '" . DB::Escape($this->id) . "' && `eid` = '" . DB::Escape($this->euser->id) . "'";
			$res = DB::Query($q);
			$hasevaluated = array();
			if (@mysql_num_rows($res) > 0)
				{
				while ($r = mysql_fetch_array($res))
					{
					$hasevaluated["{$r['assessed']}"] = true;
					}
				}

			foreach ($eaArray as $e)
				{
				if ($e == $this->evaluation['assessed'])
					{
					$issel = " selected='selected'";
					}
				if (!$hasevaluated["{$e}"] || $this->evaluation['assessed'] != null)
					{
					$this->hasAssignedUsers = true;
					$companylist .= "<option value='{$e}'{$issel}>{$eNames["$e"]}</option>";
					}
				}

			}
		else
			{
			$this->hasAssignedUsers = false;
			}


		/*
		$this->GetCompanyUsers();
		if ($this->companyusers != null)
			{
			foreach ($this->companyusers as $cu_i => $cu_v)
				{
				$issel = "";
				if ($cu_i == $this->evaluation['assessed'])
					{
					$issel = " selected='selected'";
					}
				$companylist .= "<option value='{$cu_i}'{$issel}>{$cu_v}</option>";
				}
			}
		*/

		/*
		$d .= "<tr>";
		$d .= "<td class='oef-bginfo_tbl_left'>{$MES['your_name']}</td>";
		$d .= "<td class='oef-bginfo_tbl_right'><input type='text' class='oef-bginfo_input_text' name='name' value=\"" . htmlspecialchars($this->evaluation['name']) . "\"/></td>";
		$d .= "</tr>";
		*/

		if ($this->evaluation['eid'])
			{

		$hd .= "<div class='oef-stats_report_head'>";
		$hd .= "<div class='oef-stats_report_head_left'>";
		$hd .= "{$MES['evaluated_by']} &#187; <strong>{$this->euser->first_name} {$this->euser->last_name}</strong>";
		$hd .= "</div><!-- oef-stats_report_head_left -->";
		$hd .= "<div class='oef-stats_report_head_right'>";
		$hd .= "{$MES['employee_assessed']} &#187; <strong>{$this->auser->first_name} {$this->auser->last_name}</strong>";
		$hd .= "</div><!-- oef-stats_report_head_right -->";
		$hd .= "</div><!-- oef-stats_report_head -->";
/*
			$d .= "<tr>";
			$d .= "<td class='oef-bginfo_tbl_left'>{$MES['evaluated_by']}</td>";
			$d .= "<td class='oef-bginfo_tbl_right'> &#187; <strong>{$this->euser->first_name} {$this->euser->last_name}</strong></td>";
			$d .= "</tr>";
			$d .= "<tr>";
			$d .= "<td class='oef-bginfo_tbl_left'>{$MES['employee_assessed']}</td>";
			$d .= "<td class='oef-bginfo_tbl_right'> &#187; <strong>{$this->auser->first_name} {$this->auser->last_name}</strong></td>";
			$d .= "</tr>";
*/
			}
		else
			{
			if (false && $this->type == 2)
				{
				$d .= "<tr>";
				$d .= "<td class='oef-bginfo_tbl_left'>{$MES['employee_assessed']}</td>";
				$d .= "<td class='oef-bginfo_tbl_right'><select class='oef-bginfo_input_select' name='assessed'><option value=''></option>{$companylist}</select></td>";
				$d .= "</tr>";
				}
			}
		/*
		$d .= "<tr>";
		$d .= "<td class='oef-bginfo_tbl_left'>{$MES['your_position']}</td>";
		$d .= "<td class='oef-bginfo_tbl_right'><input type='text' class='oef-bginfo_input_text' name='title' value=\"" . htmlspecialchars($this->evaluation['title']) . "\"/></td>";
		$d .= "</tr>";

		$d .= "<tr>";
		$d .= "<td class='oef-bginfo_tbl_left'>{$MES['your_department']}</td>";
		$d .= "<td class='oef-bginfo_tbl_right'><input type='text' class='oef-bginfo_input_text' name='department' value=\"" . htmlspecialchars($this->evaluation['department']) . "\"/></td>";
		$d .= "</tr>";
		*/

		/*
		$d .= "<tr>";
		$d .= "<td class='oef-bginfo_tbl_left'>{$MES['manager']}</td>";
		$d .= "<td class='oef-bginfo_tbl_right'><input type='text' class='oef-bginfo_input_text' name='manager' value=\"" . htmlspecialchars($this->evaluation['manager']) . "\"/></td>";
		$d .= "</tr>";
		*/

		/*
		$d .= "<tr>";
		$d .= "<td class='oef-bginfo_tbl_left'>{$MES['date']}</td>";
		$d .= "<td class='oef-bginfo_tbl_right'>";
		$d .= "<select class='oef-bginfo_input_select' name='mm'>";
		for ($i = 1; $i <= 12; $i++)
			{
			$fi = $i;
			if ($fi < 10)
				{
				$fi = "0{$i}";
				}
			$d .= "<option value='{$fi}'>" . $MES["month{$i}"] . "</option>";
			}
		$d .= "</select> ";
		$d .= "<select class='oef-bginfo_input_select' name='dd'>";
		for ($i = 1; $i <= 31; $i++)
			{
			$fi = $i;
			if ($fi < 10)
				{
				$fi = "0{$i}";
				}
			$d .= "<option value='{$fi}'>{$i}</option>";
			}
		$d .= "</select> ";
		$d .= "<select class='oef-bginfo_input_select' name='yyyy'>";
		$year = date("Y");
		$minyear = $year - 1;
		$maxyear = $year + 1;
		for ($i = $minyear; $i <= $maxyear; $i++)
			{
			$d .= "<option value='{$i}'>{$i}</option>";
			}
		$d .= "</select>";
		$d .= "</td>";
		$d .= "</tr>";
		*/

		$d .= "</table>";

		/*
		$d .= "<div class='oef-bginfo_who'>";
		$d .= "<div class='oef-bginfo_who'>";
		if ($this->evaluation == null)
			{
			$d .= "<span class='oef-bginfo_who_tick'>{$MES['please_tick']}</span> ";
			}
		$d .= "{$MES['i_am_their']}";
		$d .= "</div><!-- end oef-bginfo_who -->";
		$d .= "<ul class='oef-bginfo_who_list'>";
		$a = array("1"=>$MES['manager'], "2"=>$MES['direct_report'], "3"=>$MES['colleague_peer'], "4"=>$MES['myself']);
		foreach ($a as $e_i => $e_v)
			{
			$issel = "";
			if ($e_i == $this->evaluation['iam'])
				{
				$issel = " checked='checked'";
				}
			$d .= "<li class='oef-bginfo_who_li'><input type='radio' class='oef-bginfo_input_radio' name='iam' value='{$e_i}'{$issel}/> {$e_v}</li>";
			}
		$d .= "</ul>";
		$d .= "</div><!-- end oef-bginfo_who -->";
		*/


		$d .= "</div><!-- end oef-bginfo -->";

		return $hd . $d;
		}


	function WriteInFields ()
		{
		global $MES;
		$d .= "<div class='oef-writeins'>";
		/*
		$d .= "<div class='oef-writein'>";
		$d .= $MES['think_start'];
		$d .= "<div class='oef-writein_textarea'>";
		$d .= "<textarea class='oef-writein_input_textarea' name='start'></textarea>";
		$d .= "</div><!-- end oef-writein_textarea -->";
		$d .= "</div><!-- end oef-writein -->";
		$d .= "<div class='oef-writein'>";
		$d .= $MES['think_stop'];
		$d .= "<div class='oef-writein_textarea'>";
		$d .= "<textarea class='oef-writein_input_textarea' name='stop'></textarea>";
		$d .= "</div><!-- end oef-writein_textarea -->";
		$d .= "</div><!-- end oef-writein -->";
		$d .= "<div class='oef-writein'>";
		$d .= $MES['think_continue'];
		$d .= "<div class='oef-writein_textarea'>";
		$d .= "<textarea class='oef-writein_input_textarea' name='continue'></textarea>";
		$d .= "</div><!-- end oef-writein_textarea -->";
		$d .= "</div><!-- end oef-writein -->";
		*/
		if ($this->wins != null)
			{
			$count = 0;
			foreach ($this->wins as $w)
				{
				$count++;
				$d .= "<div class='oef-writein'>";
				$d .= $w;
				$d .= "<div class='oef-writein_textarea'>";
				$d .= "<textarea class='oef-writein_input_textarea' name='w-{$count}'>" . str_replace("<br/>", "\n", $this->evaluation['wins']["{$count}"]) . "</textarea>";
				$d .= "</div><!-- end oef-writein_textarea -->";
				$d .= "</div><!-- end oef-writein -->";
				}
			}
		$d .= "</div><!-- end oef-writeins -->";
		return $d;
		}


	function Delete ()
		{
		$q = "DELETE FROM `" . TBLPRE . "surveys` WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		DB::Query($q);
		}


	function ProcessForm ()
		{
		global $MES;
		$ncid = $_POST['next_cid'];
		$count = 1;
		for ($ci = 1; $ci < $ncid; $ci++)
			{
			if ($_POST["competency_{$ci}"] != null)
				{
				$com .= "{$count}|" . $_POST["competency_{$ci}"] . "\n";
				$nbid = $_POST["oef-sform-nbid-{$ci}"];
				for ($bi = 1; $bi < $nbid; $bi++)
					{
					if ($_POST["behavior_{$ci}_{$bi}"] != null)
						{
						$beh .= "{$count}|" . $_POST["behavior_{$ci}_{$bi}"] . "\n";
						}
					}
				$count++;
				}
			}
		$nwid = $_POST['next_wid'];
		for ($wi = 1; $wi < $nwid; $wi++)
			{
			if ($_POST["writeins_{$wi}"] != null)
				{
				$win .= $_POST["writeins_{$wi}"] . "\n";
				}
			}
		$com = rtrim($com);
		$beh = rtrim($beh);
		$win = rtrim($win);
		if ($this->id != null && $_POST['duplicate'] != 1)
			{
			$q = "UPDATE `" . TBLPRE . "surveys` SET `name` = '" . DB::Escape($_POST['survey_name']) . "', ";
			$q .= "`competencies` = '" . DB::Escape($com) . "', ";
			$q .= "`questions` = '" . DB::Escape($beh) . "', ";
			$q .= "`writeins` = '" . DB::Escape($win) . "', ";
			$q .= "`partner` = '" . DB::Escape($_POST['partner']) . "',";
			$q .= "`type` = '" . DB::Escape($_POST['type']) . "'";
			$q .= " WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
			DB::Query($q);
			$d .= $MES['survey_updated'];
			}
		else
			{
			$q = "INSERT INTO `" . TBLPRE . "surveys` (`name`, `competencies`, `questions`, `created`, `writeins`, `partner`, `type`) VALUES(";
			$q .= "'" . DB::Escape($_POST['survey_name']) . "', ";
			$q .= "'" . DB::Escape($com) . "', ";
			$q .= "'" . DB::Escape($beh) . "', ";
			$q .= "'" . time() . "', ";
			$q .= "'" . DB::Escape($win) . "', ";
			$q .= "'" . DB::Escape($_POST['partner']) . "',";
			$q .= "'" . DB::Escape($_POST['partner']) . "'";
			$q .= ")";
			DB::Query($q);
			$d .= $MES['survey_created'];
			}
		return $d;
		}


	function Form ()
		{
		global $MES, $page;
		$langMessages .= "<script type=\"text/javascript\">\n";
		$langMessages .= "langMes['info'] = \"{$MES['info']}\";\n";
		$langMessages .= "langMes['create_survey'] = \"{$MES['create_survey']}\";\n";
		$langMessages .= "langMes['update_survey'] = \"{$MES['update_survey']}\";\n";
		$langMessages .= "langMes['competency'] = \"{$MES['competency']}\";\n";
		$langMessages .= "langMes['behavior'] = \"{$MES['behavior']}\";\n";
		$langMessages .= "langMes['writein'] = \"{$MES['writein']}\";\n";
		$langMessages .= "langMes['competency_desc'] = \"{$MES['competency_desc']}\";\n";
		$langMessages .= "langMes['behavior_desc'] = \"{$MES['behavior_desc']}\";\n";
		$langMessages .= "langMes['writein_desc'] = \"{$MES['writein_desc']}\";\n";
		$langMessages .= "</script>\n";
		$page->SetVar('head', $langMessages);
		$showform = true;
		if ($_POST['process'] != null)
			{
			$showform = false;
			$d .= $this->ProcessForm();
			}
		if ($showform)
			{
			$ncid = 1;
			$wcid = 1;
			$button = $MES['create_survey'];
			if ($this->id != null)
				{
				$ncid += $this->comCount;
				$wcid += $this->winCount;
				$button = $MES['update_survey'];
				}
			$d .= "<form id='oef-sform-form' name='oef-sform-form' method='POST' action='{$_SERVER['REQUEST_URI']}'>";
			$d .= "<input type='hidden' name='process' value='y'/>";
			$d .= "<input type='hidden' id='oef-sform-ncid' name='next_cid' value='{$ncid}'/>";
			$d .= "<div class='oef-sform_title'>";
			$d .= $MES['name_of_survey'];
			$d .= "<input type='text' class='oef-sform_title_input' name='survey_name' value=\"" . htmlspecialchars($this->name) . "\"/>";
			$d .= "</div><!-- end oef-sform_title -->";
			// partner
			$d .= "<div class='oef-sform_partner'>";
			$d .= $MES['company_assigned_to'];
			$d .= "<select class='oef-sform_partner_select' name='partner' onchange=\"previousPartnerState = this.selectedIndex;\"><option value='0'></option>";
			$q = "SELECT `id`, `first_name`, `last_name`, `company` FROM `" . TBLPRE . "users` WHERE `type` = '1' && `company` != '' ORDER BY `company` ASC";
			$res = DB::Query($q);
			if (@mysql_num_rows($res) > 0)
				{
				while ($r = mysql_fetch_array($res))
					{
					$issel = "";
					if ($this->partner != null && $this->partner == $r['id'])
						{
						$issel = " selected='selected'";
						}
					$d .= "<option value='{$r['id']}'{$issel}>{$r['company']}</option>";
					}
				}
			$d .= "</select>";
			$d .= "</div><!-- end oef-sform_title -->";


			$d .= "<div class='oef-sform_partner'>";
			$d .= $MES['use_this_survey_for'];
			$d .= "<select class='oef-sform_partner_select' name='type'><option value='0'></option>";
			$typeArray = array('1'=>$MES['customers'], '2'=>$MES['employees']);
			foreach ($typeArray as $t_i => $t_v)
				{
				$issel = "";
				if ($this->type != null && $this->type == $t_i)
					{
					$issel = " selected='selected'";
					}
				$d .= "<option value='{$t_i}'{$issel}>{$t_v}</option>";
				}
			$d .= "</select>";
			$d .= "</div><!-- end oef-sform_title -->";

			$d .= "<div class='oef-sform_tickable'>";
			$d .= "<div id='oef-sform'>";
			if ($this->coms != null)
				{
				foreach ($this->coms as $c_i => $c_v)
					{
					$d .= $this->FormCompetency($c_i);
					}
				}
			$d .= "</div><!-- end oef-sform -->";

			$d .= "<div class='oef-sform_com_pane'>";
			$d .= "<input type='button' class='oef-sform_input_button' value=\"" . htmlspecialchars($MES['add_competency']) . "\" onclick=\"addCompetency();\"/>";
			$d .= "<img class='oef-sform_icon' src='pics/info_24x24.png' alt='help' onclick=\"infoDialog(1);\"/>";
			$d .= "</div><!-- end oef-sform_com_pane -->";

			$d .= "</div><!-- end oef-sform_tickable -->";

			$d .= "<div class='oef-sform_writeins'>";
			$d .= "<input type='hidden' id='oef-sform-wcid' name='next_wid' value='{$wcid}'/>";
			$d .= "<div id='oef-sform-writeins'>";
			if ($this->wins != null)
				{
				for ($i = 1; $i <= $this->winCount; $i++)
					{
					$d .= $this->WriteIn($i);
					}
				}
			$d .= "</div><!-- end oef-sform-writeins -->";
			$d .= "<input type='button' class='oef-sform_input_button' value=\"" . htmlspecialchars($MES['add_writein']) . "\" onclick=\"addWriteIn();\"/>";
			$d .= "<img class='oef-sform_icon' src='pics/info_24x24.png' alt='help' onclick=\"infoDialog(2);\"/>";
			$d .= "</div><!-- end oef-sform_writeins -->";
			if ($this->id != null)
				{
				$d .= "<div class='oef-sform_duplicate'>";
				$d .= "<input type='checkbox' class='oef-sform_duplicate_checkbox' name='duplicate' value='1' onclick=\"toggleDuplicate();\"/>";
				$d .= $MES['duplicate_info'];
				$d .= "</div><!-- end oef-sform_duplicate -->";
				}
			$d .= "<div class='oef-sform_submit'>";
			$d .= "<input type='submit' class='oef-sform_submit_button' id='oef-sform-submit-button' value=\"" . htmlspecialchars($button) . "\"/>";
			$d .= "</div><!-- end oef-sform_submit -->";
			$d .= "</form>";
			}
		return "<div class='oef-sform'>" . $d . "</div><!-- end oef-sform -->";
		}


	function FormCompetency ($cid)
		{
		global $MES;
		$bCount = 0;
		$nbid = 1;
		if ($this->ques["{$cid}"] != null)
			{
			$bCount = count($this->ques["{$cid}"]);
			$nbid += $bCount;
			}
		$d .= "<div id='oef-com-{$cid}' class='oef-sform_com'>";
		$d .= "<div class='oef-sform_com_left'>";
		$d .= "<img class='oef-sform_icon' src='pics/delete_24x24.png' alt='delete' onclick=\"removeCompetency({$cid});\"/>";
		$d .= "<input type='text' class='oef-sform_com_input_text' name='competency_{$cid}' value=\"" . htmlspecialchars($this->coms[$cid]) . "\"/>";
		$d .= "</div><!-- end oef-sform_com_left -->";
		$d .= "<div class='oef-sform_com_right'>";
		$d .= "<input type='hidden' name='oef-sform-nbid-{$cid}' id='oef-sform-nbid-{$cid}' value='{$nbid}'/>";
		$d .= "<div id='oef-sform-com-beh-{$cid}'>";
		if ($bCount > 0)
			{
			for ($i = 1; $i <= $bCount; $i++)
				{
				$d .= $this->FormBehavior($cid, $i);
				}
			}
		$d .= "</div>";
		$d .= "<input type='button' class='oef-sform_input_button' value=\"" . htmlspecialchars($MES['add_behavior']) . "\" onclick=\"addQuestion($cid);\"/>";
		$d .= "<img class='oef-sform_icon' src='pics/info_24x24.png' alt='help' onclick=\"infoDialog(3);\"/>";
		$d .= "</div><!-- end oef-sform_com_right -->";
		$d .= "</div><!-- oef-sform_com -->";

		return $d;
		}


	function FormBehavior ($cid, $bid)
		{
		$bIndex = $bid - 1;
		$d .= "<div id='oef-beh-{$cid}-{$bid}' class='oef-sform_beh'>";
		$d .= "<img class='oef-sform_icon' src='pics/delete_24x24.png' alt='delete' onclick=\"removeQuestion({$cid}, {$bid});\"/>";
		$d .= "<input type='text' class='oef-sform_beh_input_text' name='behavior_{$cid}_{$bid}' value=\"" . htmlspecialchars($this->ques["{$cid}"][$bIndex]) . "\"/>";
		$d .= "</div><!-- end oef-sform_beh -->";
		return $d;
		}


	function NewCompetencyDialog ()
		{
		global $MES;
		$d .= "<div class='oef-dialog'>";
		$d .= "<div class='oef-dialog_head'>{$MES['enter_competency']}</div><!-- end oef-dialog_head -->";
		$d .= "<div class='oef-dialog_body'>";
		$d .= "<form id='oef-sform-ncom-form'>";
		$d .= "<input type='text' class='oef-sform_dialog_input_text' name='new_competency' id='oef-sform-com'/>";
		$d .= "<input type='button' class='oef-sform_dialog_input_button' value=\"" . htmlspecialchars($MES['add']) . "\" onclick=\"addCompetency();\"/>";
		$d .= "</form>";
		$d .= "</div><!-- end oef-dialog_body -->";
		$d .= "<div class='oef-dialog_foot'></div><!-- end oef-dialog_foot -->";
		$d .= "</div><!-- end oef-dialog -->";
		return $d;
		}


	function WriteIn ($wiid)
		{
		$wIndex = $wiid - 1;
		$d .= "<div id='oef-win-{$wiid}' class='oef-sform_writein'>";
		$d .= "<img class='oef-sform_icon' src='pics/delete_24x24.png' alt='delete' onclick=\"removeWriteIn({$wiid});\"/>";
		$d .= "<input type='text' class='oef-sform_writein_input' name='writeins_{$wiid}' value=\"" . htmlspecialchars($this->wins[$wIndex]) . "\"/>";
		$d .= "</div><!-- end oef-sform_writein -->";
		return $d;
		}





	}


?>
