<?php


class Manage
	{


	function Manage ()
		{
		$this->useContainer = true;
		$this->sortField = 'id';
		$this->sortMode = 'ASC';
		$this->start = 0;
		$this->num = 50;
		}


	function GetTotal ()
		{
		if ($this->type == 1)
			{
			$tbl = "surveys";
			}
		elseif ($this->type == 2)
			{
			$tbl = "users";
			}
		elseif ($this->type == 3)
			{
			$tbl = "evaluations";
			}
		elseif ($this->type == 4)
			{
			$tbl = "users";
			}
		$q = "SELECT COUNT(*) FROM `" . TBLPRE . "{$tbl}`{$this->filter}";
		$res = DB::Query($q);
		$this->total = mysql_result($res, 0, 0);
		return $total;
		}


	function GetList ()
		{
		global $MES, $page, $user;
		if ($this->type == 1)
			{
			$confirmDeleteMes = $MES['confirm_delete_survey'];
			$successDeleteMes = $MES['delete_survey_success'];
			if ($user->type == 2)
				{
				$this->tblhead = array(""=>"&nbsp;", "id"=>$MES['id'], "name"=>$MES['name'], "partner"=>$MES['company_assigned_to'], 'visible'=>$MES['visible']);
				$visupd = "langMes['visibility_updated'] = \"" . str_replace("\"", "\\\"", $MES['visibility_updated']) . "\";\n";
				}
			else
				{
				$this->tblhead = array(""=>"&nbsp;", "id"=>$MES['id'], "name"=>$MES['name'], "partner"=>$MES['company_assigned_to']);
				}

			$sqltbl = "surveys";
			$this->varray = array('1'=>$MES['yes'], "0"=>$MES['no']);
			}
		elseif ($this->type == 2)
			{
			$confirmDeleteMes = $MES['confirm_delete_user'];
			$successDeleteMes = $MES['delete_user_success'];
			if ($user->type == 1)
				{
				$this->filter = " WHERE `type` = '0' && `creator` = '" . DB::Escape($user->id) . "'";
				$this->tblhead = array(""=>"&nbsp;", "id"=>$MES['id'], "first_name"=>$MES['first_name'], "last_name"=>$MES['last_name'], "creator"=>$MES['company']);
				}
			else
				{
				$this->tblhead = array(""=>"&nbsp;", "id"=>$MES['id'], "name"=>$MES['username'], "first_name"=>$MES['first_name'], "last_name"=>$MES['last_name'], "creator"=>$MES['company'], "type"=>$MES['account_type']);
				}
			$sqltbl = "users";
			}
		elseif ($this->type == 3)
			{
			$confirmDeleteMes = $MES['confirm_delete_eval'];
			$successDeleteMes = $MES['delete_eval_success'];
			$this->tblhead = array("420"=>"&nbsp;", ""=>"&nbsp;", "eid"=>$MES['evaluated_by'], "iam"=>$MES['role'], "time"=>$MES['evaluation_date']);
			$sqltbl = "evaluations";
			$this->filter = " WHERE `assessed` = '" . DB::Escape($this->user->id) . "' && `survey` = '" . DB::Escape($this->survey->id) . "'";
			}
		elseif ($this->type == 4)
			{
			if ($user->type == 1)
				{
				$onlypartner = " && `id` = '" . DB::Escape($user->id) . "'";
				}
			$this->tblhead = array("creator"=>$MES['company'], ""=>$MES['evaluation_data'], "participants"=>$MES['participants']);
			$this->filter = " WHERE `type` = '1'{$onlypartner}";
			$sqltbl = "users";
			}
		$langMessages .= "<script type=\"text/javascript\">\n";
		$langMessages .= $visupd;
		$langMessages .= "langMes['confirm_delete'] = \"{$confirmDeleteMes}\";\n";
		$langMessages .= "langMes['delete_success'] = \"{$successDeleteMes}\";\n";
		$langMessages .= "</script>\n";
		$page->SetVar('head', $langMessages);
		$this->companies = array();
		$this->tblrows = array();

		$cq .= "SELECT `id`, `company` FROM `" . TBLPRE . "users` WHERE `type` = '1' && `company` != ''";
		$res = DB::Query($cq);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				$this->companies["{$r['id']}"] = $r['company'];
				}
			}
		$q = "SELECT * FROM `" . TBLPRE . "{$sqltbl}`{$this->filter} ORDER BY `{$this->sortField}` {$this->sortMode} LIMIT " . DB::Escape($this->start) . ", " . DB::Escape($this->num);
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res, MYSQL_ASSOC))
				{
				if ($this->type == 2 && $r['type'] == 0)
					{
					$r['company'] = $this->companies["{$r['creator']}"];
					}
				if ($this->type == 4)
					{
					$tsq = "SELECT `id` FROM `" . TBLPRE . "surveys` WHERE `partner` = '{$r['id']}'";
					$tsres = DB::Query($tsq);
					$pcq = "SELECT `eid` FROM `" . TBLPRE . "evaluations`";
					if (@mysql_num_rows($tsres) > 0)
						{
						$pcq .= " WHERE";
						while ($tsr = mysql_fetch_array($tsres))
							{
							$pcq .= "`survey` = '{$tsr['id']}' || ";
							}
						$pcq = rtrim($pcq, " |");
						$pcres = DB::Query($pcq);
						if (@mysql_num_rows($pcres) > 0)
							{
							$pcarray = array();
							while ($pcr = mysql_fetch_array($pcres))
								{
								$pcarray[] = $pcr['eid'];
								}
							$pcarray = array_unique($pcarray);
							$r['participants'] = count($pcarray);
							}
						else
							{
							$r['participants'] = 0;
							}
						}
					else
						{
						$r['participants'] = 0;
						}
					}
				$this->tblrows[] = $r;
				}
			}
		$mp = $this->MorePages();
		//$d .= "<div class='oef-manage'>";
		if ($this->useContainer)
			{
			$d .= "<div class='oef-manage' id='oef-manage-list'>";
			}
		$d .= $mp;
		$d .= $this->MakeTable();
		$d .= $mp;
		if ($this->useContainer)
			{
			$d .= "</div><!-- end oef-manage-list -->";
			}
		//$d .= "</div><!-- end oef-manage -->";
		return $d;
		}


	function MakeTable ()
		{
		$d .= "<div class='oef-manage_tbl_container'>";
		$d .= "<table class='oef-manage_tbl'>";
		$d .= "<tr>";
		if ($this->tblhead != null)
			{
			$count = 0;
			foreach ($this->tblhead as $h_i => $h_v)
				{
				$count++;
				$sort = '';
				$clickclass = '';
				if ($count > 1 && ($this->type != 4 || $count != 3))
					{
					if ($this->sortField == $h_i && $this->sortMode == 'ASC')
						{
						$sortMode = 'DESC';
						}
					else
						{
						$sortMode = 'ASC';
						}
					$clickclass = " oef-manage_tbl_head_click";
					$sort = " onclick=\"loadList({$this->type}, 0, '{$h_i}', '{$sortMode}', '{$this->survey->id}', '{$this->user->id}');\"";
					}
				$d .= "<td class='oef-manage_tbl_head{$clickclass}'{$sort}>{$h_v}</td>";
				}
			}
		$d .= "</tr>";
		if ($this->tblrows != null)
			{
			foreach ($this->tblrows as $r)
				{
				$d .= $this->MakeRow($r);
				}
			}
		$d .= "</table>";
		$d .= "</div><!-- end oef-manage_tbl_container -->";
		return $d;
		}


	function MakeRow ($r)
		{
		global $MES, $user;
		$d .= "<tr id='man-row-{$r['id']}'>";
		if ($this->type == 1 || $this->type == 2)
			{
			$d .= "<td class='oef-manage_tbl_cell'>";
			$d .= "<img class='oef-manage_icon' src='pics/edit_24x24.png' alt='edit' onclick=\"reqEdit({$this->type}, {$r['id']});\"/>";
			$d .= "<img class='oef-manage_icon' src='pics/delete_24x24.png' alt='edit' onclick=\"reqDelete({$this->type}, {$r['id']});\"/>";
			if ($this->type == 2 && $r['type'] == 0)
				{
				//$d .= "<img class='oef-manage_icon' src='pics/line_graph_24x24.png' alt='feedback' onclick=\"reqStats({$this->type}, {$r['id']});\"/>";
				}
			$d .= "</td>";
			}
		if ($this->type == 1)
			{
			$d .= "<td class='oef-manage_tbl_cell'>{$r['id']}</td>";
			$d .= "<td class='oef-manage_tbl_cell'>{$r['name']}</td>";
			$partner = $MES['not_applicable'];
			if ($r['partner'] != 0)
				{
				$partner = $this->companies["{$r['partner']}"];
				}
			$d .= "<td class='oef-manage_tbl_cell'>{$partner}</td>";
			if ($user->type == 2)
				{
				foreach ($this->varray as $v_i => $v_v)
					{
					$issel = '';
					if ($v_i == $r['visible'])
						{
						$issel = " selected='selected'";
						}
					$vlist .= "<option value='{$v_i}'{$issel}>{$v_v}</option>";
					}
				$d .= "<td class='oef-manage_tbl_cell'><select onchange=\"updateSurveyVisibility({$r['id']}, '" . str_replace("'", "\\'", $r['name']) . "', this.value);\">{$vlist}</select></td>";
				}
			//$d .= "<td class='oef-manage_tbl_cell'>" . $this->FormatDate($r['created']) . "</td>";
			}
		elseif ($this->type == 2)
			{
			if ($r['type'] == 2)
				{
				$atype = $MES['admin'];
				}
			elseif ($r['type'] == 1)
				{
				$atype = $MES['partner'];
				}
			else
				{
				$atype = $MES['employee'];
				}
			$d .= "<td class='oef-manage_tbl_cell'>{$r['id']}</td>";
			if ($user->type == 2)
				{
				$d .= "<td class='oef-manage_tbl_cell'>{$r['name']}</td>";
				}
			$d .= "<td class='oef-manage_tbl_cell'>{$r['first_name']}</td>";
			$d .= "<td class='oef-manage_tbl_cell'>{$r['last_name']}</td>";
			$d .= "<td class='oef-manage_tbl_cell'>{$r['company']}</td>";
			if ($user->type == 2)
				{
				$d .= "<td class='oef-manage_tbl_cell'>{$atype}</td>";
				}
			}
		elseif ($this->type == 3)
			{
			$d .= "<td class='oef-manage_tbl_cell'>";
			$d .= "<img class='oef-manage_icon' src='pics/delete_24x24.png' alt='edit' onclick=\"reqDelete({$this->type}, {$r['id']});\"/>";
			$d .= "</td>";
			$d .= "<td class='oef-manage_tbl_cell'><a class='oef-manage_tbl_link' href='index.php?id={$this->survey->id}&evaluation={$r['id']}'>{$MES['view_results']}</a></td>";
			if ($r['eid'] != null)
				{
				$eu = new User($r['eid']);
				$ename = $eu->first_name . " " . $eu->last_name;
				}
			$d .= "<td class='oef-manage_tbl_cell'>{$ename}</td>";
			$rArray = array("1"=>$MES['manager'], "2"=>$MES['direct_report'], "3"=>$MES['colleague_peer'], "4"=>$MES['myself']);
			$d .= "<td class='oef-manage_tbl_cell'>" . $rArray["{$r['iam']}"] . "</td>";
			$d .= "<td class='oef-manage_tbl_cell'>" . $this->FormatDate($r['time']) . "</td>";
			}
		elseif ($this->type == 4)
			{
			$d .= "<td class='oef-manage_tbl_cell'>{$r['company']}</td>";
			$d .= "<td class='oef-manage_tbl_cell'><a class='oef-manage_tbl_link' href='index.php?do=manage&what=reports&partner={$r['id']}&op=company'>{$MES['evaluations_and_report']}</a></td>";
			$d .= "<td class='oef-manage_tbl_cell'>{$r['participants']}</td>";
			}
		$d .= "</tr>";
		return $d;
		}


	function FormatDate ($ts)
		{
		global $MES;
		$month = date("n", $ts);
		$day = date("j", $ts);
		$year = date("Y", $ts);
		return $MES["month{$month}"] . " {$day}, $year";
		}


	function MorePages ()
		{
		global $MES;
		$this->GetTotal();
		if ($this->type == 1)
			{
			$what = $MES['surveys'];
			if ($this->total == 1)
				{
				$what = $MES['survey'];
				}
			}
		elseif ($this->type == 2 || $this->type == 4)
			{
			$what = $MES['users'];
			if ($this->total == 1)
				{
				$what = $MES['user'];
				}
			}
		elseif ($this->type == 3)
			{
			$what = $MES['evaluations'];
			if ($this->total == 1)
				{
				$what = $MES['evaluations'];
				}
			}
		$pages = $this->total / $this->num;
		if (!is_int($pages))
			{
			$pages++;
			}
		$d .= "<div class='oef-mp'>";
		$d .= "<div class='oef-mp_left'>";
		$d .= str_replace(array('$x', '$what'), array("<span class='oef-mp_total'>{$this->total}</span>", "<span class='oef-mp_what'>{$what}</span>"), $MES['x_what_total']);
		$d .= " | ";
		$end = $this->start + $this->num;
		if ($end > $this->total)
			{
			$end = $this->total;
			}
		$d .= str_replace(array('$what', '$from', '$to'), array($what, ($this->start + 1), $end), $MES['displaying_what_from_to']);
		$d .= "</div><!-- end oef-mp_left -->";
		$d .= "<div class='oef-mp_right'>";
		$d .= $MES['page'] . "<select class='oef-mp_select' id='oef-mp-select' onchange=\"loadList({$this->type}, this.value, '{$this->sortField}', '{$this->sortMode}');\">";
		$start = 0;
		for ($i = 1; $i <= $pages; $i++)
			{
			$issel = "";
			if ($start == $this->start)
				{
				$issel = " selected='selected'";
				}
			$d .= "<option value='{$start}'{$issel}>{$i}</option>";
			$start += $this->num;
			}
		$d .= "</select>";
		$pl = array();
		if ($this->start > 0)
			{
			$pstart = $this->start - $this->num;
			$pl[] = "<a class='oef-mp_link' onclick=\"loadList({$this->type}, {$pstart}, '{$this->sortField}', '{$this->sortMode}');\">{$MES['previous_page']}</a>";
			}
		if ($this->total > ($this->start + $this->num))
			{
			$pstart = $this->start + $this->num;
			$pl[] = "<a class='oef-mp_link' onclick=\"loadList({$this->type}, {$pstart}, '{$this->sortField}', '{$this->sortMode}');\">{$MES['next_page']}</a>";
			}
		if ($pl != null)
			{
			$d .= " | ";
			foreach ($pl as $l)
				{
				$pls .= "{$l} - ";
				}
			}
		$d .= rtrim($pls, " -");
		$d .= "</div><!-- end oef-mp_right -->";
		$d .= "</div><!-- end oef-mp -->";
		return $d;
		}


	}


?>
