<?php
define(MYSQL_HOST, "ss360eval.db.5324370.hostedresource.com");
define(MYSQL_USER, "ss360eval");
define(MYSQL_PASS, "v5KVJGxcCZvTqF");
define(MYSQL_DBNM, "ss360eval");
define(TBLPRE, "oef2_");
define(BASE_URL, "http://www.tamayyaz.com/CompanyFeedback");
define(LOGO_WIDTH, null);
define(LOGO_HEIGHT, 100);
define(LOGO_DEFAULT, "Tamayyaz.gif");
?>