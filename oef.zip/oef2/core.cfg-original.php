<?php
define(MYSQL_HOST, "localhost");
define(MYSQL_USER, "oef2");
define(MYSQL_PASS, "Bu9phMDRrTGPGjw9");
define(MYSQL_DBNM, "oef2");
define(TBLPRE, "oef2_");
define(BASE_URL, "http://sikosoft.net/clients/oef2");
define(LOGO_WIDTH, null);
define(LOGO_HEIGHT, 100);
define(LOGO_DEFAULT, "Tamayyaz.gif");
?>
