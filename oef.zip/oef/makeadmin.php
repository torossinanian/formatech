<?php

require('cfg.php');

if (DB::Query("INSERT INTO `oef_users` (`creator`, `name`, `first_name`, `last_name`, `email`, `password`, `type`, `company`) VALUES 
(0, 'admin', 'John', 'Doe', '', '1a1dc91c907325c69271ddf0c944bc72', 2, '')"))
	{
	echo "Admin account created successfully!";
	}
else
	{
	echo "There was a problem creating the admin user; are you sure the database/tables exist already?";
	}

?>
