<?php

require("cfg.php");

//DB::Query("ALTER TABLE `oef_users` ADD `eac` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ");
//DB::Query("ALTER TABLE `oef_surveys` ADD `visible` TINYINT( 1 ) NOT NULL DEFAULT '1'");

DB::Query("ALTER TABLE `oef_users` ADD `ea` LONGTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL");
DB::Query("ALTER TABLE `oef_evaluations` DROP `name`");
DB::Query("ALTER TABLE `oef_evaluations` ADD `eid` INT( 10 ) NOT NULL DEFAULT '0' AFTER `survey`");

?>
