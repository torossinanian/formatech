<?php

define("BASE", dirname(__FILE__));

// require main logic/class files
require("lib/System.php");
require("lib/Survey.php");
require("lib/User.php");
require("lib/Page.php");

// require the language file
require("lib/lang/en.php");

// load the configuration settings & mySQL credentials
require("core.cfg.php");

// load the database class
require("lib/DB.php");

define("COOKIE_USER", "ss_oef_user");
define("COOKIE_PASS", "ss_oef_pass");
define("COOKIE_SESS", "ss_oef_sess");

// build some objects used everywhere
$db = new DB;
$user = new User($_COOKIE[COOKIE_USER]);
$page = new Page;
$sys = new System;


?>
