<?php


class User
	{


	function User ($id = null)
		{
		$this->ip = $_SERVER['REMOTE_ADDR'];
		$this->uagent = $_SERVER['HTTP_USER_AGENT'];
		$this->id = $id;
		if ($this->id != null)
			{
			$this->GetData();
			}
		}


	function GetData ()
		{
		$q = "SELECT * FROM `" . TBLPRE . "users` WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			$r = mysql_fetch_array($res, MYSQL_ASSOC);
			foreach ($r as $r_i => $r_v)
				{
				$this->$r_i = $r_v;
				}
			}
		}


	function PasswordForm ()
		{
		global $MES;
		$showform = true;
		$d .= "<div class='oef-updpas'>";
		if ($_POST['process'] == 'y')
			{
			if ($_POST['password1'] == null || $_POST['password2'] == null)
				{
				$err[] = $MES['missing_pass_field'];
				}
			if ($_POST['password1'] != $_POST['password2'])
				{
				$err[] = $MES['pass1_pass2_mismatch'];
				}
			// one or more errors were encountered
			if (count($err) > 0)
				{
				$d .= "<div class='oef-errors'>";
				$d .= "<div class='oef-errors_head'>{$MES['uh_oh_errors']}</div>";
				$d .= "<ul>";
				foreach ($err as $e)
					{
					$d .= "<li>{$e}</li>";
					}
				$d .= "</ul>";
				$d .= "</div>";
				}
			else
				{
				$showform = false;
				$this->raw_password = $_POST['password1'];
				$this->UpdatePassword();
				$d .= $MES['password_updated'];
				}
			}
		if ($showform)
			{
			$d .= "<form method='POST' action='{$_SERVER['REQUEST_URI']}'>";
			$d .= "<input type='hidden' name='process' value='y'/>";
			$d .= "<table class='oef-updpas_tbl'>";
			$d .= "<tr>";
			$d .= "<td class='oef-updpas_tbl_left'>{$MES['new_password']}</td>";
			$d .= "<td class='oef-updpas_tbl_right'><input type='password' class='oef-updpas_input_text' name='password1' id='pass1'/></td>";
			$d .= "</tr>";
			$d .= "<tr>";
			$d .= "<td class='oef-updpas_tbl_left'>{$MES['retype_password']}</td>";
			$d .= "<td class='oef-updpas_tbl_right'><input type='password' class='oef-updpas_input_text' name='password2' id='pass2'/></td>";
			$d .= "</tr>";
			$d .= "</table>";
			$d .= "<div class='oef-updpas_submit'>";
			$d .= "<input type='submit' class='oef-updpas_input_button' value=\"" . htmlspecialchars($MES['update_password']) . "\"/>";
			$d .= "</div><!-- end oef-updpas_submit -->";
			$d .= "</form>";
			}
		$d .= "</div><!-- end oef-updpas -->";
		return $d;
		}


	function UpdatePassword ()
		{
		global $user;
		$this->password = md5($this->raw_password);
		$q = "UPDATE `" . TBLPRE . "users` SET `password` = '" . DB::Escape($this->password) . "' WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		DB::Query($q);
		if ($user->id == $this->id)
			{
			setcookie(COOKIE_PASS, md5(md5($this->raw_password)), 0, "/");
			}
		}


	function Form ()
		{
		global $MES, $page, $user;
		$langMessages .= "<script type=\"text/javascript\">\n";
		$langMessages .= "langMes['error'] = \"{$MES['error']}\";\n";
		$langMessages .= "langMes['success'] = \"{$MES['success']}\";\n";
		$langMessages .= "langMes['account_result_1'] = \"{$MES['account_created']}\";\n";
		$langMessages .= "langMes['account_result_2'] = \"{$MES['username_taken']}\";\n";
		$langMessages .= "langMes['account_result_3'] = \"{$MES['invalid_username']}\";\n";
		$langMessages .= "langMes['account_result_4'] = \"{$MES['account_updated']}\";\n";
		$langMessages .= "</script>\n";
		$page->SetVar('head', $langMessages);
		$d .= "<div class='oef-account'>";
		if ($this->id != null)
			{
			if ($this->id != $user->id)
				{
				$andid = "&id={$this->id}";
				}
			$d .= "<div class='oef-account_updpas'>";
			$d .= "<a class='oef-account_updpas_link' href='index.php?do=password{$andid}'>{$MES['update_password']}</a>";
			$d .= "</div><!-- end oef-account_updpas -->";
			}
		$d .= "<form id='account-form' name='account-form'>";
		if ($this->id != null)
			{
			$d .= "<input type='hidden' name='id' value='{$this->id}'/>";
			$button = $MES['update_account'];
			}
		else
			{
			$button = $MES['create_account'];
			}
		$d .= "<table class='oef-account_tbl'>";
		// type
		if ($user->type == 2 || ($user->type == 1 && $user->id != $this->id))
			{
			$d .= "<tr>";
			$d .= "<td class='oef-account_tbl_left'>{$MES['account_type']}</td>";
			$d .= "<td class='oef-account_tbl_right'><select name='type' class='oef-account_input_select' onchange=\"toggleAccountType();\">";
			if ($user->type == 2)
				{
				$atypes = array("0"=>$MES['employee'], "1"=>$MES['partner'], "2"=>$MES['admin']);
				}
			elseif ($user->type == 1)
				{
				$atypes = array("0"=>$MES['employee']);
				}
			else
				{
				$atypes = array();
				}
			$pretype = $this->type;
			if ($this->type == null)
				{
				$pretype = 1;
				}
			foreach ($atypes as $a_i => $a_v)
				{
				$issel = '';
				if ($a_i == $pretype)
					{
					$issel = " selected='selected'";
					}
				$d .= "<option value='{$a_i}'{$issel}>{$a_v}</option>";
				}
			$d .= "</select></td>";
			$d .= "</tr>";
			}
		else
			{
			$hiddentype = "<input type='hidden' name='type' value='{$this->type}'/>";
			}
		// username
		$d .= "<tr id='acc-row-usn'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['username']}</td>";
		$d .= "<td class='oef-account_tbl_right'>";
		$d .= "<input type='text' class='oef-account_input_text' name='username' value=\"" . htmlspecialchars($this->name) . "\"/>";
		$d .= "</td>";
		$d .= "</tr>";
		// first name
		$d .= "<tr id='acc-row-fsn'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['first_name']}</td>";
		$d .= "<td class='oef-account_tbl_right'>";
		$d .= "<input type='text' class='oef-account_input_text' name='first_name' value=\"" . htmlspecialchars($this->first_name) . "\"/>";
		$d .= "</td>";
		$d .= "</tr>";
		// last name
		$d .= "<tr id='acc-row-lsn'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['last_name']}</td>";
		$d .= "<td class='oef-account_tbl_right'>";
		$d .= "<input type='text' class='oef-account_input_text' name='last_name' value=\"" . htmlspecialchars($this->last_name) . "\"/>";
		$d .= "</td>";
		$d .= "</tr>";
		// email
		$d .= "<tr id='acc-row-eml'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['email']}</td>";
		$d .= "<td class='oef-account_tbl_right'>";
		$d .= "<input type='text' class='oef-account_input_text' name='email' value=\"" . htmlspecialchars($this->email) . "\"/>";
		$d .= "</td>";
		$d .= "</tr>";
		// password
		if ($this->id == null)
			{
			$d .= "<tr id='acc-row-pas'>";
			$d .= "<td class='oef-account_tbl_left'>{$MES['password']}</td>";
			$d .= "<td class='oef-account_tbl_right'>";
			$d .= "<input type='text' class='oef-account_input_text' name='password' value=\"" . htmlspecialchars($this->password) . "\"/>";
			$d .= "</td>";
			$d .= "</tr>";
			}
		// company
		$d .= "<tr id='acc-row-com'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['company']}</td>";
		$d .= "<td class='oef-account_tbl_right'>";
		$d .= "<input type='text' class='oef-account_input_text' name='company' value=\"" . htmlspecialchars($this->company) . "\"/>";
		$d .= "</td>";
		$d .= "</tr>";
		// assigned-to
		if ($user->type == 2)
			{
			$d .= "<tr id='acc-row-ass'>";
			$d .= "<td class='oef-account_tbl_left'>{$MES['assigned_to']}</td>";
			$d .= "<td class='oef-account_tbl_right'><select class='oef-account_input_select' name='assigned' onchange=\"toggleAssignedUsers(this.value);\"><option value='0'></option>";
			$q = "SELECT `id`, `company` FROM `" . TBLPRE . "users` WHERE `type` = '1' && `company` != '' ORDER BY `company` ASC";
			$res = DB::Query($q);
			if (@mysql_num_rows($res) > 0)
				{
				while ($r = mysql_fetch_array($res))
					{
					$issel = "";
					if ($r['id'] == $this->creator)
						{
						$issel = " selected='selected'";
						}
					$d .= "<option value='{$r['id']}'{$issel}>{$r['company']}</option>";
					}
				}
			$d .= "</select></td>";
			$d .= "</tr>";
			}
		// employee access code
		if ($this->id != null)
			{
			$d .= "<tr id='acc-row-eac'>";
			$d .= "<td class='oef-account_tbl_left'>{$MES['evaluation_access_code']}</td>";
			$d .= "<td class='oef-account_tbl_right'>";
			$d .= "<input type='text' class='oef-account_input_text' name='eac' value=\"" . htmlspecialchars($this->eac) . "\"/>";
			$d .= "</td>";
			$d .= "</tr>";
			}
		// employees assigned
		if ($user->type == 1)
			{
			$pid = $user->id;
			}
		if ($this->type == 0 && $this->creator != 0)
			{
			$pid = $this->creator;
			}
		$d .= "<tr id='acc-row-eas'>";
		$d .= "<td class='oef-account_tbl_left'>{$MES['employees_assigned']}</td>";
		$d .= "<td class='oef-account_tbl_right'><div id='oef-usr-frm-asn-dat'>" . $this->AssignedList($pid, $this->ea) . "</div><!-- end oef-usr-frm-asn-dat --></td>";
		$d .= "</tr>";
		// end main table
		$d .= "</table>";
		$d .= $hiddentype;
		$d .= "</form>";
		// auto-toggle account type
		$d .= "<script type='text/javascript'>toggleAccountType();</script>";
		// submit area
		$d .= "<div class='oef-account_submit'>";
		$d .= "<input type='button' class='oef-account_input_button' value=\"" . htmlspecialchars($button) . "\" onclick=\"processAccountForm();\"/>";
		$d .= "</div><!-- end oef-account_submit -->";
		// end main div
		$d .= "</div><!-- end oef-account -->";
		return $d;
		}


	function AssignedList ($pid, $assigned = null)
		{
		global $MES;
		$isassigned = array();
		if ($assigned != null)
			{
			$aArray = explode(",", $assigned);
			foreach ($aArray as $a)
				{
				list($uid, $rid) = explode("=", $a);
				$isassigned["{$uid}"] = true;
				$alist .= $this->AssignedUser($uid, $rid, $aNames["$uid"]);
				}
			}
		$d .= "<select class='oef-account_input_select' name='ea' id='oef-usr-frm-ass-lst'><option value=''>---</option>";
		$q = "SELECT `id`, `first_name`, `last_name` FROM `" . TBLPRE . "users` WHERE `type` = '0' && `creator` = '{$pid}' ORDER BY `first_name` ASC, `last_name` ASC";
		$res = DB::Query($q);
		$aNames = array();
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				$aNames["{$r['id']}"] = "{$r['first_name']} {$r['last_name']}";
				$disabled = '';
				if ($isassigned["{$r['id']}"])
					{
					$disabled = " disabled='disabled'";
					}
				$d .= "<option value='{$r['id']}' id='oef-ass-lst-{$r['id']}'{$disabled}>" . $aNames["{$r['id']}"] . "</option>";
				}
			}
		$d .= "</select> &#187; <input type='button' value=\"{$MES['add']}\" onclick=\"addAssigned(\$('#oef-usr-frm-ass-lst').val());\"/>";
		$d .= "<div id='oef-usr-frm-asn'>";
		$d .= $alist;
		$d .= "</div><!-- end oef-usr-frm-asn -->";
		return $d;
		}


	function AssignedUser ($uid, $rid = null, $name = null)
		{
		global $MES;
		if ($name == null)
			{
			$u = new User($uid);
			$name = "{$u->first_name} {$u->last_name}";
			}
		$rArray = array("1"=>$MES['manager'], "2"=>$MES['direct_report'], "3"=>$MES['colleague_peer'], "4"=>$MES['myself']);
		foreach ($rArray as $r_i => $r_v)
			{
			$issel = "";
			if ($rid == $r_i)
				{
				$issel = " selected='selected'";
				}
			$rList .= "<option value='{$r_i}'{$issel}>{$r_v}</option>";
			}
		$d .= "<div id='oef-usr-frm-asn-{$uid}' style='margin:2px'><input type='hidden' name='employees_assigned[]' value='{$uid}'/><img src='pics/delete_24x24.png' align='absmiddle' alt='delete' style='cursor:pointer;' onclick=\"removeAssigned({$uid});\"/> {$name} &#187; <select name='assigned_relationship[]'>{$rList}</select></div>";
		return $d;
		}


	function Create ()
		{
		global $user;
		$creator = $user->id;
		$cq = "SHOW TABLE STATUS LIKE '" . TBLPRE . "users'";
		$cqres = DB::Query($cq);
		$cqr = mysql_fetch_assoc($cqres);
		$nid = $cqr['Auto_increment'];
		if ($user->type != 2)
			{
			$this->type = 0;
			}
		else
			{
			if ($this->assigned != 0)
				{
				$creator = $this->assigned;
				}
			elseif ($this->type == 1)
				{
				$creator = $nid;
				$this->SendPartnerEmail();
				}
			}
		if ($this->type == 0)
			{
			$this->eac = $nid . $this->RandomEAC();
			$eac_field = ", `eac`";
			$eac_value = ", '" . DB::Escape($this->eac) . "'";
			$eaArray = $_POST['employees_assigned'];
			$eaCount = count($_POST['employees_assigned']);
			if ($eaArray != null)
				{
				for ($i = 0; $i < $eaCount; $i++)
					{
					$ea .= "{$_POST['employees_assigned'][$i]}={$_POST['assigned_relationship'][$i]},";
					}
				}
			$eas_field = ", `ea`";
			$eas_value = ", '" . DB::Escape(rtrim($ea, ",")) . "'";
			}
		$q = "INSERT INTO `" . TBLPRE . "users` (`creator`, `name`, `first_name`, `last_name`, `email`, `password`, `type`, `company`{$eac_field}{$eas_field})";
		$q .= " VALUES(";
		$q .= "'" . DB::Escape($creator) . "', ";
		$q .= "'" . DB::Escape($this->name) . "', ";
		$q .= "'" . DB::Escape($this->first_name) . "', ";
		$q .= "'" . DB::Escape($this->last_name) . "', ";
		$q .= "'" . DB::Escape($this->email) . "', ";
		$q .= "'" . DB::Escape(md5($this->password)) . "', ";
		$q .= "'" . DB::Escape($this->type) . "', ";
		$q .= "'" . DB::Escape($this->company) . "'";
		$q .= $eac_value . $eas_value;
		$q .= ")";
		DB::Query($q);
		$this->id = mysql_insert_id();
		return $this->id;
		}


	function RandomEAC ($length = 8, $seeds = null)
		{
		if ($seeds == null)
			{
			$seeds = 'abcdefghijklmnopqrstuvwxyz0123456789';
			}
		$str = '';
		$seeds_count = strlen($seeds);
		list($usec, $sec) = explode(' ', microtime());
		$seed = (float) $sec + ((float) $usec * 100000);
		mt_srand($seed);
		for ($i = 0; $length > $i; $i++)
			{
			$str .= $seeds{mt_rand(0, $seeds_count - 1)};
			}
		return $str;
		}


	function SendPartnerEmail ()
		{
		global $MES;
		$emldat = file_get_contents("lib/partner_email.txt");
		$f = array(
			'{$name}',
			'{$loginurl}',
			'{$username}',
			'{$password}',
			'{$createurl}',
			'{$eac}'
			);
		if ($this->first_name != null || $this->last_name != null)
			{
			$name = $this->first_name . " " . $this->last_name;
			}
		else
			{
			$name = $this->name;
			}
		$r = array(
			trim($name),
			BASE_URL . "/index.php?do=login",
			$this->name,
			$this->password,
			BASE_URL . "/index.php?do=manage&what=users&op=form",
			$this->eac
			);
		$emldat = str_replace($f, $r, $emldat);
		$to = str_replace("\n","",$this->email);
		$to = str_replace("\r","",$to);
		$subject = str_replace("\n","",$MES['partner_subject']);
		$subject = str_replace("\r","",$subject);
		$from_name = str_replace("\n","",$MES['partner_from_name']);
		$from_name = str_replace("\r","",$from_name);
		$from_email = str_replace("\n","",$MES['partner_from_email']);
		$from_email = str_replace("\r","",$from_email);
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "X-MSMail-Priority: Normal\r\n";
		$headers .= "X-Mailer: MailQ / PHP\r\n";
		$headers .= "From: \"$from_name\" <$from_email>\r\n";
		mail($to, $subject, $emldat, $headers);
		}


	function Update ()
		{
		global $user;
		if ($user->type != 2)
			{
			if ($user->type == 1 && $user->id == $this->id)
				{
				$this->type = 1;
				}
			else
				{
				$this->type = 0;
				}
			}
		else
			{
			if ($this->assigned != 0)
				{
				$assigned = "`creator` = '" . DB::Escape($this->assigned) . "', ";
				}
			if ($this->type == 1)
				{
				if ($this->assigned == 0)
					{
					$assigned = "`creator` = '" . DB::Escape($this->id) . "', ";
					}
				}
			}
		if ($this->type == 0)
			{
			$eaArray = $_POST['employees_assigned'];
			$eaCount = count($_POST['employees_assigned']);
			if ($eaArray != null)
				{
				for ($i = 0; $i < $eaCount; $i++)
					{
					$ea .= "{$_POST['employees_assigned'][$i]}={$_POST['assigned_relationship'][$i]},";
					}
				}
			$eac = "`eac` = '" . DB::Escape($this->eac) . "', ";
			$eas = "`ea` = '" . DB::Escape(rtrim($ea, ",")) . "', ";
			}
		$q .= "UPDATE `" . TBLPRE . "users` SET `name` = '" . DB::Escape($this->name) . "', ";
		$q .= "`first_name` = '" . DB::Escape($this->first_name) . "', ";
		$q .= "`last_name` = '" . DB::Escape($this->last_name) . "', ";
		$q .= "`email` = '" . DB::Escape($this->email) . "', ";
		//$q .= "`password` = '" . DB::Escape($this->password) . "', ";
		$q .= "`type` = '" . DB::Escape($this->type) . "', ";
		$q .= $assigned;
		$q .= $eac;
		$q .= $eas;
		$q .= "`company` = '" . DB::Escape($this->company) . "'";
		$q .= " WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		DB::Query($q);
		}


	function UserNameIsValid ($name)
		{
		$len = strlen($name);
		if ($len < 3)
			{
			return false;
			}
		if (!preg_match("/^[a-zA-Z]{1}[a-zA-Z0-9_]{1,23}[a-zA-Z0-9]{1}$/", $name))
			{
			return false;
			}
		return true;
		}


	function CleanUserName ($name)
		{
		$name = preg_replace("/[^A-Za-z0-9_\-]/", "\\1", $name);
		}


	function UserNameIsTaken ($name)
		{
		$q = "SELECT `id` FROM `" . TBLPRE . "users` WHERE `name` LIKE '" . DB::Escape($name) . "' && `id` != '" . DB::Escape($this->id) . "' LIMIT 1";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			return true;
			}
		else
			{
			return false;
			}
		}


	function Delete ()
		{
		$q = "DELETE FROM `" . TBLPRE . "users` WHERE `id` = '" . DB::Escape($this->id) . "' LIMIT 1";
		DB::Query($q);
		DB::Query("DELETE FROM `" . TBLPRE . "evaluations` WHERE `assessed` = '" . DB::Escape($this->id) . "'");
		}


	function Logout ()
		{
		setcookie(COOKIE_USER, null, -1, "/");
		setcookie(COOKIE_PASS, null, -1, "/");
		setcookie(COOKIE_SESS, null, -1, "/");
		header("Location: " . BASE_URL . "/index.php");
		}


	function Login ($uid, $pass)
		{
		setcookie(COOKIE_USER, $uid, 0, "/");
		setcookie(COOKIE_PASS, md5(md5($pass)), 0, "/");
		// create a session in order for validation
		$sq = "INSERT INTO `" . TBLPRE . "sessions` (`ip`, `host`, `uagent`, `name`, `itime`) VALUES('" . DB::Escape($this->ip) . "','" . @gethostbyaddr($this->ip) . "', '" . DB::Escape($this->uagent) . "', '" . DB::Escape($uid) . "','" . time() . "');";
		$sres = DB::Query($sq);
		$sid = mysql_insert_id();
		setcookie(COOKIE_SESS, $sid, 0, "/");
		header("Location: " . BASE_URL . "/index.php");
		}


	function ValidateLogin ($userid, $password)
		{
		$userid = strtolower($userid);
		if (preg_match("/^[0-9]{1,10}$/", $userid))
			{
			$field = "id";
			}
		else
			{
			$field = "name";
			}
		$q = "SELECT `id`, `password` FROM `" . TBLPRE . "users` WHERE `{$field}` = '" . DB::Escape($userid) . "' LIMIT 1";
		$res = DB::Query($q);
		if (mysql_num_rows($res) == 0)
			{
			return 'err3';
			}
		else
			{
			list($uid, $realpass) = mysql_fetch_array($res);
			if ($password != null && $realpass == md5($password))
				{
				return $uid;
				}
			else
				{
				return 'err2';
				}
			}
		}


	function IsLoggedIn ()
		{
		if ($_COOKIE[COOKIE_USER] != null)
			{
			return true;
			}
		else
			{
			return false;
			}
		}


	function IsAdmin ()
		{
		if ($this->uservals['type'] == 2)
			{
			return true;
			}
		else
			{
			return false;
			}
		}


	function ValidSession ()
		{
		$q = "SELECT * FROM `" . TBLPRE . "sessions` WHERE `id` = '" . DB::Escape($_COOKIE[COOKIE_SESS]) . "' && `name` = '" . DB::Escape($this->id) . "'";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			if ($this->password != null && md5($this->password) == $_COOKIE[COOKIE_PASS])
				{
				return true;
				}
			else
				{
				return false;
				}
			}
		else
			{
			return false;
			}
		}


	function LoginForm ()
		{
		global $MES;
		$showform = true;
		$err = array();
		if ($_POST['mode'] == 'login' && $_POST['login_id'] != null && $_POST['login_password'] != null)
			{
			$result = $this->ValidateLogin($_POST['login_id'], $_POST['login_password']);
			if ($result == 'err2')
				{
				$err[] = $MES['incorrect_password'];
				}
			elseif ($result == 'err3')
				{
				$err[] = $MES['username_cant_be_found'];
				}
			elseif (preg_match("/^[0-9]{1,10}$/",$result))
				{
				$showform = false;
				$this->Login($result, $_POST['login_password']);
				}
			// one or more errors were encountered
			if (count($err) > 0)
				{
				$d .= "<div class='oef-errors'>";
				$d .= "<div class='oef-errors_head'>{$MES['uh_oh_errors']}</div>";
				$d .= "<ul>";
				foreach ($err as $e)
					{
					$d .= "<li>{$e}</li>";
					}
				$d .= "</ul>";
				$d .= "</div>";
				}
			}
		if ($showform)
			{
			$d .= "<form action='{$_SERVER['REQUEST_URI']}' method='POST'>";
			$d .= "<input type='hidden' name='mode' value='login'/>";
			$d .= "<table class='oef-lform_tbl'>";
			$d .= "<tr>";
			$d .= "<td class='oef-lform_tbl_left'>{$MES['username_or_id']}</td>";
			$d .= "<td class='oef-lform_tbl_right'><input type='text' name='login_id' size='30' class='oef-lform_input_text'/></td>";
			$d .= "</tr>";
			$d .= "<tr>";
			$d .= "<td class='oef-lform_tbl_left'>{$MES['password']}</td>";
			$d .= "<td class='oef-lform_tbl_right'><input type='password' name='login_password' size='30' class='oef-lform_input_text'/></td>";
			$d .= "</tr>";
			$d .= "</table>";
			$d .= "<div class='oef-lform_submit'><input type='submit' value=\"{$MES['login']}\" class='oef-lform_input_submit'/></div>";
			$d .= "</form>";
			$d .= "</div>";
			}
		return "<div class='oef-lform'>{$d}</div>";
		}


	function GetUserIDFromAC ($code)
		{
		$q = "SELECT `id` FROM `" . TBLPRE . "users` WHERE `eac` = '" . DB::Escape($code) . "' && `type` = '0' LIMIT 1";
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			list($id) = mysql_fetch_array($res);
			return $id;
			}
		else
			{
			return false;
			}
		}


	}


?>
