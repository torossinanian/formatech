<?php


class System
	{


	function System ()
		{
		$this->defTblPrefix = "oef_";
		}


	function Install ()
		{
		global $MES;
		$this->SetupDatabase();
		$d = $MES['install_success'];
		return $d;
		}


	function SetupDatabase ()
		{
		$sqldata = file("lib/db_structure.sql");
		foreach ($sqldata as $lineid => $lineval)
			{
			$sqldata[$lineid] = str_replace("\r","",$lineval);
			if (substr($lineval,0,1) != "-")
				{
				$createq .= $lineval;
				}
			}
		$qs = explode(";\n\n\n",$createq);
		foreach ($qs as $q)
			{
			$q = str_replace("`{$this->defTblPrefix}", "`" . TBLPRE, $q);
			DB::Query($q);
			}
		}


	function IsInstalled ()
		{
		static $state;
		if (!isset($state))
			{
			$q = "SELECT `id` FROM . `" . TBLPRE . "users` LIMIT 1";
			$res = @DB::Query($q);
			if (@mysql_num_rows($res) == 1)
				{
				$state = true;
				}
			else
				{
				$state = false;
				}
			}
		return $state;
		}


	}


?>
