<?php


class DB
	{

	function DB ()
		{
		$this->type = 1;
		$this->host = MYSQL_HOST;
		$this->user = MYSQL_USER;
		$this->pass = MYSQL_PASS;
		$this->dbnm = MYSQL_DBNM;
		$this->querycount = 0;
		$this->queryarray = array();
		$this->connection = $this->Connect();
		if (!$this->connection)
			{
			//error (2, "Cannot connect to mySQL server.", "1");
			}
		if (!$this->SelectDB())
			{
			//error (3, "Cannot open database.", "1");
			}
		}

	function Connect ()
		{
		return @mysql_connect($this->host, $this->user, $this->pass);
		}

	function SelectDB ()
		{
		return @mysql_select_db($this->dbnm);
		}

	function Query ($query)
		{
		global $DB, $USER;
		$DB->querycount++;
		$result = mysql_query($query);
		return $result;
		}


	function Escape ($str)
		{
		return mysql_real_escape_string ($str); // was stripping slashes (removed on jul 21)
		}



	}


?>
