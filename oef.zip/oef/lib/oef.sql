-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2010 at 10:53 AM
-- Server version: 5.0.32
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oef`
--

-- --------------------------------------------------------

--
-- Table structure for table `oef_averages`
--

CREATE TABLE IF NOT EXISTS `oef_averages` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `user` int(10) NOT NULL default '0',
  `all` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oef_evaluations`
--

CREATE TABLE IF NOT EXISTS `oef_evaluations` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `assessed` int(10) NOT NULL default '0',
  `title` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `department` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `manager` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam` tinyint(1) NOT NULL default '0',
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oef_sessions`
--

CREATE TABLE IF NOT EXISTS `oef_sessions` (
  `id` int(15) NOT NULL auto_increment,
  `ip` varchar(15) character set utf8 collate utf8_unicode_ci NOT NULL,
  `host` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `itime` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`),
  KEY `name` (`name`),
  KEY `itime` (`itime`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0;

-- --------------------------------------------------------

--
-- Table structure for table `oef_surveys`
--

CREATE TABLE IF NOT EXISTS `oef_surveys` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `competencies` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `created` int(10) NOT NULL default '0',
  `partner` int(10) NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oef_users`
--

CREATE TABLE IF NOT EXISTS `oef_users` (
  `id` int(10) NOT NULL auto_increment,
  `creator` int(10) NOT NULL default '0',
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  `type` int(2) NOT NULL default '0',
  `company` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `eac` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
