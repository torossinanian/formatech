<?php


class Stats
	{


	function Stats ()
		{
		$this->cacheDuration = 0;
		$this->scoreSet['height'] = 40;
		$this->scoreSet['seglength'] = 80;
		$this->scoreSet['segcount'] = 4;
		$this->scoreSet['segwidth'] = 1;
		$this->scoreSet['segheight'] = 16;
		$this->scoreSet['segcolor'] = "#666";
		$this->scoreSet['bordercolor'] = "#000";
		$this->scoreSet['bordersize'] = 3;
		$this->scoreSet['averagesize'] = 6;
		$this->scoreSet['averagecolor'] = "#f00";
		$this->scoreSet['barheight'] = 24;
		$this->scoreSet['barlowcolor'] = "#b00";
		$this->scoreSet['barmedcolor'] = "#990";
		$this->scoreSet['barhigcolor'] = "#090";
		$this->scoreSet['barnumcolor'] = "#fff";
		$this->scoreSet['barnumsize'] = 18;
		}


	function Calculate ($score)
		{
		$score = round($score * (($this->scoreSet['segcount'] + 1) / 5), 1);
		return $score;
		}


	function Score ($score = null, $average = null, $head = false)
		{
		global $page;
		static $cssSet;
		$score = $this->Calculate($score);
		$average = $this->Calculate($average);
		if ($head)
			{
			$desc = true;
			$baseclass = "oef-score_desc";
			}
		else
			{
			$baseclass = "oef-score";
			}

		$css .= "<style type='text/css'>\n";
		$css .= ".oef-score\n";
		$css .= "\t{\n";
		$css .= "\tdisplay: block;\n";
		$css .= "\tposition: relative;\n";
		$css .= "\twidth: " . ($this->scoreSet['segcount'] * $this->scoreSet['seglength']) . "px;\n";
		$css .= "\theight: {$this->scoreSet['height']}px;\n";
		$css .= "\tborder: {$this->scoreSet['bordersize']}px {$this->scoreSet['bordercolor']} solid;\n";
		$css .= "\t}\n";


		$css .= ".oef-score_desc\n";
		$css .= "\t{\n";
		$css .= "\tdisplay: block;\n";
		$css .= "\tposition: relative;\n";
		$css .= "\twidth: " . ($this->scoreSet['segcount'] * $this->scoreSet['seglength']) . "px;\n";
		$css .= "\theight: {$this->scoreSet['height']}px;\n";
		$css .= "\tborder-bottom: {$this->scoreSet['bordersize']}px {$this->scoreSet['bordercolor']} solid;\n";
		$css .= "\t}\n";

		$d .= "<div class='{$baseclass}'>";
		$d .= $this->ScoreSegments($head);
		if (!$head)
			{
			$d .= $this->ScoreAverage($average);
			$d .= $this->ScoreBar($score);
			}
		else
			{
			$d .= $this->ScoreDesc();
			}
		$d .= "</div><!-- end oef-score -->";

		//$d .= $this->ScoreKey();
		$css .= "</style>";
		if (!isset($cssSet))
			{
			$page->SetVar('head', $css);
			$cssSet = true;
			}
		return $d;
		}


	function ScoreDesc ()
		{
		global $MES;
		//$top = -round(($this->scoreSet['segheight'] / 2));
		$top = $this->scoreSet['height'] - ($this->scoreSet['segheight'] * 2);
		for ($i = 0; $i <= $this->scoreSet['segcount']; $i++)
			{
			$si = $i + 1;
			$left = $i * $this->scoreSet['seglength'] - (round($this->scoreSet['seglength'] / 5));
			$d .= "<div style='z-index:2; position: absolute; top: {$top}px; left: {$left}px; width: {$this->scoreSet['segwidth']}px; height: {$this->scoreSet['segheight']}px; font-size:70%;'>" . $MES["score_{$si}"] . "</div>";
			}
		return $d;
		}


	function ScoreSegments ($desc = false)
		{
		$top = -round(($this->scoreSet['segheight'] / 2));
		if ($desc)
			{
			$top += $this->scoreSet['height'];
			}
		for ($i = 0; $i <= $this->scoreSet['segcount']; $i++)
			{
			$left = $i * $this->scoreSet['seglength'];
			$d .= "<div style='z-index:2; position: absolute; top: {$top}px; left: {$left}px; width: {$this->scoreSet['segwidth']}px; height: {$this->scoreSet['segheight']}px; border-left: {$this->scoreSet['segwidth']}px {$this->scoreSet['segcolor']} solid;'></div>";
			}
		return $d;
		}


	function ScoreAverage ($average)
		{
		if ($average != null)
			{
			$left = (($average - 1) * $this->scoreSet['seglength']) - round($this->scoreSet['averagesize'] / 2);
			$d .= "<div style='z-index:2; position: absolute; top: 0; left: {$left}px; width: {$this->scoreSet['averagesize']}px; height: 100%; border-left: {$this->scoreSet['averagesize']}px {$this->scoreSet['averagecolor']} solid;'>&nbsp;</div>";
			}
		return $d;
		}


	function ScoreBar ($score)
		{
		if ($score != null)
			{
			$top = floor(($this->scoreSet['height'] - $this->scoreSet['barheight']) / 2);
			$barlength = ((($score - 1) * $this->scoreSet['seglength']) - 4);
			$barheight = $this->scoreSet['barheight'] - 4;
			$barcolor = $this->scoreSet['barhigcolor'];
			$d .= "<div style='z-index:3; position: absolute; top: {$top}px; left: 0px; width: {$barlength}px; height: {$barheight}px; background: {$barcolor}; border: 2px {$barcolor} solid;'>&nbsp;</div>";
			// number
			$numtop = $top + floor(($this->scoreSet['barheight'] - $this->scoreSet['barnumsize']) / 2);
			$numleft = round($barlength / 2);
			$d .= "<div style='z-index:4; position: absolute; top: {$numtop}px; left: {$numleft}px; font-size: {$this->scoreSet['barnumsize']}px; color: {$this->scoreSet['barnumcolor']};'>{$score}</div>";
			}
		return $d;
		}


	function ScoreKey ()
		{
		global $MES;
		$d .= "<div class='oef-key'>";
		$d .= "<div class='oef-key_head'>";
		$d .= $MES['key'];
		$d .= "</div><!-- end oef-key_head -->";
		$d .= "<div class='oef-key_info'>";
		$d .= "<div class='oef-key_info_left'>";

		$d .= "<div><span class='oef-key_green'>{$MES['green']}</span> = {$MES['a_strength']}</div>";
		$d .= "<div><span class='oef-key_yellow'>{$MES['yellow']}</span> = {$MES['possible_development_needed']}</div>";
		$d .= "<div><span class='oef-key_red'>{$MES['red']}</span> = {$MES['opportunity_for_development']}</div>";

		$d .= "</div><!-- end oef-key_info_left -->";
		$d .= "<div class='oef-key_info_right'>";

		$d .= "<span class='oef-key_norm'>&nbsp;</span> = {$MES['norm_desc']}";

		$d .= "</div><!-- end oef-key_info_right -->";
		$d .= "</div><!-- end oef-key_info -->";
		$d .= "</div><!-- end oef-key -->";
		return $d;
		}


	function MainMenu ()
		{
		global $MES, $user;
		$d .= "<div class='oef-stats'>";
		$d .= "<div class='oef-stats_menu'>";
		$d .= "<form action='index.php' method='GET'>";
		$d .= "<input type='hidden' name='do' value='stats'/>";
		$d .= "<input type='hidden' name='what' value='users'/>";
		$d .= "<input type='hidden' name='id' value='{$this->id}'/>";
		$d .= str_replace('$user', $this->user->first_name . " " . $this->user->last_name, $MES['evaluations_for_user']);
		$d .= " &#187; <select class='oef-stats_select' name='survey'>";
		$q = "SELECT sur.id, sur.name FROM `" . TBLPRE . "evaluations` as eva, `" . TBLPRE . "surveys` as sur WHERE eva.assessed = '" . DB::Escape($this->id) . "' && eva.survey = sur.id ORDER BY sur.name";
		$res = DB::Query($q);
		$setSurveys = array();
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				if (!isset($setSurveys["{$r['id']}"]))
					{
					$d .= "<option value='{$r['id']}'>{$r['name']}</option>";
					$setSurveys["{$r['id']}"] = true;
					}
				}
			}
		$d .= "</select>";
		$d .= " &#187; ";
		$d .= "<select class='oef-stats_select' name='op'>";
		$d .= "<option value='report'>{$MES['generate_report']}</option>";
		if ($user->type == 2)
			{
			$d .= "<option value='list'>{$MES['list_all_evaluations']}</option>";
			}
		$d .= "</select>";
		$d .= " &#187; ";
		$d .= "<input type='submit' class='oef-stats_menu_go' value=\"" . htmlspecialchars($MES['go']) . "\"/>";
		$d .= "</form>";
		$d .= "</div><!-- end oef-stats_menu -->";
		$d .= "</div><!-- end oef-stats -->";
		return $d;
		}


	function Report ()
		{
		global $MES, $user;
		$this->printerFormat = false;
		$baseclass = "oef-stats";
		if ($_GET['format'] == 'printer')
			{
			$this->printerFormat = true;
			$baseclass = "oef-stats_pf";
			$this->scoreSet['height'] = floor($this->scoreSet['height'] * 0.75);
			$this->scoreSet['barheight'] = floor($this->scoreSet['barheight'] * 0.75);
			}
		$this->qstats = array();
		$this->rcounts = array();
		$this->rarray = array();
		$this->average = array();
		$this->wresults = array();
		$this->s = new Survey($this->survey);
		// determine the global averages
		$this->DetermineAverages();
		// determine the user's averages
		$this->DetermineAverages($this->id);

		$this->iamc = array();
		$this->total = 0;
		for ($i = 1; $i <= 4; $i++)
			{
			if ($this->rarray["{$this->user->id}"]["iam_{$i}"] == null)
				{
				$this->iamc["{$i}"] = 0;
				}
			else
				{
				$this->rarray["{$this->user->id}"]["iam_{$i}"] = array_unique($this->rarray["{$this->user->id}"]["iam_{$i}"]);
				$this->iamc["{$i}"] = count($this->rarray["{$this->user->id}"]["iam_{$i}"]);
				}
			$this->total += $this->iamc["{$i}"];
			}

		if ($this->printerFormat)
			{
			$d .= "<div class='oef-report_title'>{$MES['report_title']}</div>";
			$d .= $this->Intro();
			}
		$d .= $this->ReportHead();
		$d .= $this->Demographics();
		if ($user->type == 2)
			{
			$d .= $this->EvaluatedBy();
			}
		$d .= $this->KeyHead();
		// question break down
		$d .= $this->BreakDown();
		if (!$this->printerFormat)
			{
			$d .= $this->ScoreKey();
			}
		$d .= $this->FocusAreas();
		$d .= $this->WriteInResults();


		return "<div class='{$baseclass}'>{$d}</div><!-- end oef-stats -->";
		}


	function Intro ()
		{
		$d = file_get_contents("lib/pf_intro.html");
		return $d;
		}


	function ReportHead ()
		{
		class_exists('Manage') || require("lib/Manage.php");
		$d .= "<div class='oef-stats_report_head'>";
		$d .= "<div class='oef-stats_report_head_left'>";
		$d .= $this->user->first_name . " " . $this->user->last_name;
		$d .= "</div><!-- oef-stats_report_head_left -->";
		$d .= "<div class='oef-stats_report_head_right'>";
		$d .= Manage::FormatDate(time());
		$d .= "</div><!-- oef-stats_report_head_right -->";
		$d .= "</div><!-- oef-stats_report_head -->";
		return $d;
		}


	function KeyHead ()
		{
		global $MES;
		$d .= "<div class='oef-stats_khead_left'>";
		$d .= $this->ByIAm(array($MES['manager']), array($MES['direct_report']), array($MES['peer']), array($MES['self']), true);
		$d .= "</div><!-- end oef-stats_khead_left -->";
		$d .= "<div class='oef-stats_khead_right'>";
		$d .= $this->Score(null, null, true);
		$d .= "</div><!-- end oef-stats_khead_right -->";
		return $d;
		}


	function FocusAreas ()
		{
		global $MES;
		$this->totalevaluations = 1;
		$d .= "<div class='oef-stats_focus'>";
		$d .= "<div class='oef-stats_focus_head'>";
		$d .= $MES['focus_areas'];
		$d .= "</div><!-- end oef-stats_focus_head -->";
		$d .= "<div class='oef-stats_focus_desc'>";
		$d .= $MES['focus_areas_desc'];
		$d .= "</div><!-- end oef-stats_focus_desc -->";


		$d .= "<div class='oef-stats_focus_type'>";
		$d .= $MES['highest_scores'];
		$d .= "</div><!-- end oef-stats_focus_type -->";
		$d .= "<table class='oef-stats_focus_tbl'>";
		$headrow .= "<tr>";
		$headrow .= "<td class='oef-stats_focus_tbl_h1'>&nbsp;</td>";
		if ($this->totalevaluations > 1)
			{
			$headrow .= "<td class='oef-stats_focus_tbl_h2'>{$MES['average_score']}</td>";
			$headrow .= "<td class='oef-stats_focus_tbl_h3'>{$MES['gap']}</td>";
			$headrow .= "<td class='oef-stats_focus_tbl_h4'>{$MES['norm']}</td>";
			}
		else
			{
			$headrow .= "<td class='oef-stats_focus_tbl_h4'>{$MES['score']}</td>";
			}
		$headrow .= "</tr>";
		$d .= $headrow;
		foreach ($this->qstats as $i => $v)
			{
			$gaparray1[$i] = $v[3];
			$gaparray2[$i] = $v[3];
			$scorearray1[$i] = $v[2];
			$scorearray2[$i] = $v[2];
			}
		$highest = $this->qstats;
		if ($this->totalevaluations > 1)
			{
			array_multisort($gaparray1, SORT_DESC, $highest);
			}
		else
			{
			array_multisort($scorearray1, SORT_DESC, $highest);
			}
		$highest = array_slice($highest, 0, 5);
		foreach ($highest as $h)
			{
			if ($h[2] == null)
				{
				$h[2] = $MES['not_applicable'];
				}
			if ($h[3] > 0)
				{
				$h[3] = "+{$h[3]}";
				}
			$d .= "<tr>";
			$d .= "<td class='oef-stats_focus_tbl_c1'>{$h[0]}. {$h[1]}</td>";
			if ($this->totalevaluations > 1)
				{
				$d .= "<td class='oef-stats_focus_tbl_c2'>{$h[2]}</td>";
				$d .= "<td class='oef-stats_focus_tbl_c3'>{$h[3]}</td>";
				$d .= "<td class='oef-stats_focus_tbl_c4'>{$h[4]}</td>";
				}
			else
				{
				$d .= "<td class='oef-stats_focus_tbl_cscore'>{$h[2]}</td>";
				}
			$d .= "</tr>";
			}
		$d .= "</table>";


		$d .= "<div class='oef-stats_focus_type'>";
		$d .= $MES['lowest_scores'];
		$d .= "</div><!-- end oef-stats_focus_type -->";
		$d .= "<table class='oef-stats_focus_tbl'>";
		$d .= $headrow;
		$lowest = $this->qstats;
		if ($this->totalevaluations > 1)
			{
			array_multisort($gaparray2, SORT_NUMERIC, $lowest);
			}
		else
			{
			array_multisort($scorearray2, SORT_NUMERIC, $lowest);
			}
		$lowest = array_slice($lowest, 0, 5);
		foreach ($lowest as $h)
			{
			if ($h[2] == null)
				{
				$h[2] = $MES['not_applicable'];
				}
			$d .= "<tr>";
			$d .= "<td class='oef-stats_focus_tbl_c1'>{$h[0]}. {$h[1]}</td>";
			if ($this->totalevaluations > 1)
				{
				$d .= "<td class='oef-stats_focus_tbl_c2'>{$h[2]}</td>";
				$d .= "<td class='oef-stats_focus_tbl_c3'>{$h[3]}</td>";
				$d .= "<td class='oef-stats_focus_tbl_c4'>{$h[4]}</td>";
				}
			else
				{
				$d .= "<td class='oef-stats_focus_tbl_cscore'>{$h[2]}</td>";
				}
			$d .= "</tr>";
			}
		$d .= "</table>";

		$d .= "</div><!-- end oef-stats_focus -->";
		return $d;
		}


	function Demographics ()
		{
		global $MES;
		$d .= "<div class='oef-stats_demo'>";
		$d .= "<div class='oef-stats_demo_head'>";
		$d .= $MES['demographic_summary'];
		$d .= "</div><!-- oef-stats_demo_head -->";
		$d .= "<table class='oef-stats_demo_tbl'>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_demo_tbl_left oef-stats_demo_tbl_tot_left'>{$MES['total']}</td>";
		$d .= "<td class='oef-stats_demo_tbl_right oef-stats_demo_tbl_tot_right'>{$this->total}</td>";
		$d .= "</tr>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_demo_tbl_left'>{$MES['managers']}</td>";
		$d .= "<td class='oef-stats_demo_tbl_right'>{$this->iamc['1']}</td>";
		$d .= "</tr>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_demo_tbl_left'>{$MES['direct_reports']}</td>";
		$d .= "<td class='oef-stats_demo_tbl_right'>{$this->iamc['2']}</td>";
		$d .= "</tr>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_demo_tbl_left'>{$MES['peers']}</td>";
		$d .= "<td class='oef-stats_demo_tbl_right'>{$this->iamc['3']}</td>";
		$d .= "</tr>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_demo_tbl_left'>{$MES['myself']}</td>";
		$d .= "<td class='oef-stats_demo_tbl_right'>{$this->iamc['4']}</td>";
		$d .= "</tr>";
		$d .= "<tr>";
		$d .= "</table>";
		/*
		if ($this->rarray["{$this->user->id}"]['iam_1'] != null)
			{
			$list = '';
			foreach ($this->rarray["{$this->user->id}"]['iam_1'] as $p)
				{
				$list .= "{$p}, ";
				}
			$list = rtrim($list, ", ");
			$d .= "<div class='oef-stats_demo_managers'><span class='oef-stats_demo_managers_desc'>{$MES['managers_who_evaluated']}</span> {$list}</div>";
			}
		if ($this->rarray["{$this->user->id}"]['iam_2'] != null)
			{
			$list = '';
			foreach ($this->rarray["{$this->user->id}"]['iam_2'] as $p)
				{
				$list .= "{$p}, ";
				}
			$list = rtrim($list, ", ");
			$d .= "<div class='oef-stats_demo_supervisors'><span class='oef-stats_demo_supervisors_desc'>{$MES['supervisors_who_evaluated']}</span> {$list}</div>";
			}
		*/
		$d .= "</div><!-- oef-stats_demo -->";
		return $d;
		}


	function EvaluatedBy ()
		{
		global $MES;
		$d .= "<div class='oef-stats_evby'>";
		$d .= "<div class='oef-stats_evby_head'>";
		$d .= $MES['evaluated_by'];
		$d .= "</div><!-- oef-stats_evby_head -->";
		$this->rarray["{$this->user->id}"]['all'] = array_unique($this->rarray["{$this->user->id}"]['all']);
		if ($this->rarray["{$this->user->id}"]['all'] != null)
			{
			$q = "SELECT `first_name`, `last_name`, `id` FROM `" . TBLPRE . "users` WHERE";
			foreach ($this->rarray["{$this->user->id}"]['all'] as $p)
				{
				$qstr .= "`id` = '{$p}' || ";
				}
			$q .= rtrim($qstr, " |");
			$res = DB::Query($q);
			if (@mysql_num_rows($res) > 0)
				{
				while ($r = mysql_fetch_array($res))
					{
					$names["{$r['id']}"] = "{$r['first_name']} {$r['last_name']}";
					}

				}
			$list = '';
			foreach ($this->rarray["{$this->user->id}"]['all'] as $p)
				{
				if ($names["$p"] != null)
					{
					$list .= "{$names["$p"]}, ";
					}
				}
			$list = rtrim($list, ", ");
			$d .= "<div class='oef-stats_evby_all'>{$list}</div>";
			}
		$d .= "</div><!-- oef-stats_evby -->";
		return $d;
		}


	function WriteInResults ()
		{
		if ($this->s->wins != null)
			{
			$count = 1;
			foreach ($this->s->wins as $w)
				{
				$td = "<div class='oef-stats_writein'>";
				$td .= "<div class='oef-stats_writein_head'>";
				$td .= $w;
				$td .= "</div><!-- end oef-stats_writein_head -->";
				$responses = 0;
				if ($this->wresults["{$this->user->id}"]["{$count}"] != null)
					{
					foreach ($this->wresults["{$this->user->id}"]["{$count}"] as $r_i => $r_v)
						{
						if ($r_i != null && $r_v != null)
							{
							$responses++;
							$td .= "<div class='oef-stats_writein_result'>";
							$td .= $r_v;// . " - <span class='oef-stats_writein_result_person'>{$r_i}</span>";
							$td .= "</div><!-- end oef-stats_writein_result -->";
							}
						}
					}
				$td .= "</div><!-- end oef-stats_writein -->";
				if ($responses > 0)
					{
					$d .= $td;
					}
				$count++;
				}
			}
		return $d;
		}


	function BreakDown ()
		{
		$d .= "<div class='oef-stats_bd'>";
		$qid = 0;
		foreach ($this->s->coms as $c_i => $c_v)
			{
			$cd = '';
			$qd = '';
			$redcount = 0;
			$yellowcount = 0;
			$greencount = 0;
			$ccount = 0;
			$cscore = 0;
			$caverage = 0;
			$iam1sum = 0;
			$iam2sum = 0;
			$iam3sum = 0;
			$iam4sum = 0;
			$iam1cc = 0;
			$iam2cc = 0;
			$iam3cc = 0;
			$iam4cc = 0;
			$qarray = $this->s->ques["{$c_i}"];
			foreach ($qarray as $q)
				{
				$qid++;
				$score = $this->average["{$this->id}"]["all"]["{$qid}"];
				$average = $this->average["global"]["all"]["{$qid}"];
				if ($score != 0)
					{
					$ccount++;
					$cscore += $score;
					$caverage += $average;
					}
				$iam1 = $this->Calculate($this->average["{$this->id}"]["iam_1"]["{$qid}"]);
				$iam2 = $this->Calculate($this->average["{$this->id}"]["iam_2"]["{$qid}"]);
				$iam3 = $this->Calculate($this->average["{$this->id}"]["iam_3"]["{$qid}"]);
				$iam4 = $this->Calculate($this->average["{$this->id}"]["iam_4"]["{$qid}"]);
				if ($iam1 > 0)
					{
					$iam1sum += $this->average["{$this->id}"]["iam_1"]["{$qid}"];
					$iam1cc++;
					}
				if ($iam2 > 0)
					{
					$iam2sum += $this->average["{$this->id}"]["iam_2"]["{$qid}"];
					$iam2cc++;
					}
				if ($iam3 > 0)
					{
					$iam3sum += $this->average["{$this->id}"]["iam_3"]["{$qid}"];
					$iam3cc++;
					}
				if ($iam4 > 0)
					{
					$iam4sum += $this->average["{$this->id}"]["iam_4"]["{$qid}"];
					$iam4cc++;
					}
				$iam1a = array($iam1, $this->GetColor($iam1));
				$iam2a = array($iam2, $this->GetColor($iam2));
				$iam3a = array($iam3, $this->GetColor($iam3));
				$iam4a = array($iam4, $this->GetColor($iam4));
				$qd .= "<div class='oef-stats_bd_q'>";
				$qd .= "<div class='oef-stats_bd_q_title'>";
				$qd .= $qid . ". " . $q;
				$qd .= "</div><!-- end oef-stats_bd_q_title -->";
				$qd .= "<div class='oef-stats_bd_q_info'>";
				$qd .= "<div class='oef-stats_bd_q_info_left'>";
				$qd .= $this->ByIAm($iam1a, $iam2a, $iam3a, $iam4a);
				$qd .= "</div><!-- end oef-stats_bd_q_info_left -->";
				$qd .= "<div class='oef-stats_bd_q_info_right'>";
				$qd .= $this->ByAll($score, $average);
				$qd .= "</div><!-- end oef-stats_bd_q_info_right -->";
				$qd .= "</div><!-- end oef-stats_bd_q_info -->";
				$qd .= "</div><!-- end oef-stats_bd_q -->";
				$gap = ($score - $average);
				$qsid = ($gap * 1000) + $qid;
//echo "($qid = $qsid)";
				$this->qstats[] = array($qid, $q, $score, $gap, $average);
				}
			$iam1 = $this->Calculate(@($iam1sum / $iam1cc));
			$iam2 = $this->Calculate(@($iam2sum / $iam2cc));
			$iam3 = $this->Calculate(@($iam3sum / $iam3cc));
			$iam4 = $this->Calculate(@($iam4sum / $iam4cc));
			$iam1a = array($iam1, $this->GetColor($iam1));
			$iam2a = array($iam2, $this->GetColor($iam2));
			$iam3a = array($iam3, $this->GetColor($iam3));
			$iam4a = array($iam4, $this->GetColor($iam4));
			$cd .= "<div class='oef-stats_bd_c'>";
			$cd .= "<div class='oef-stats_bd_c_title'>";
			$cd .= $c_v;
			$cd .= "</div><!-- end oef-stats_bd_c_title -->";
			$cd .= "<div class='oef-stats_bd_c_info'>";
			$cd .= "<div class='oef-stats_bd_c_info_left'>";
			$cd .= $this->ByIAm($iam1a, $iam2a, $iam3a, $iam4a);
			$cd .= "</div><!-- end oef-stats_bd_c_info_left -->";
			$cd .= "<div class='oef-stats_bd_c_info_right'>";
			$cd .= $this->ByAll(@($cscore / $ccount), @($caverage / $ccount));
			$cd .= "</div><!-- end oef-stats_bd_c_info_right -->";
			$cd .= "</div><!-- end oef-stats_bd_c_info -->";
			$cd .= "</div><!-- end oef-stats_bd_c -->";
			$d .= $cd . $qd;
			}
		$d .= "</div><!-- end oef-stats_bd -->";

		return $d;
		}


	function GetColor ($score)
		{
		$max = $this->scoreSet['segcount'] + 1;
		if ($score >= round($max * 0.666, 1))
			{
			return "green";
			}
		elseif ($score >= round($max * 0.333, 1))
			{
			return "yellow";
			}
		elseif ($score != 0)
			{
			return "red";
			}
		else
			{
			return "na";
			}
		}


	function ByIAm ($a1, $a2, $a3, $a4, $desc = false)
		{
		global $MES;
		//$d .= "<div class='oef-stats_iam_c1'>";
		if ($a1[0] == '0' || $a1[0] == null)
			{
			$a1[0] = $MES['not_applicable'];
			}
		if ($a2[0] == '0' || $a2[0] == null)
			{
			$a2[0] = $MES['not_applicable'];
			}
		if ($a3[0] == '0' || $a3[0] == null)
			{
			$a3[0] = $MES['not_applicable'];
			}
		if ($a4[0] == '0' || $a4[0] == null)
			{
			$a4[0] = $MES['not_applicable'];
			}
		if (!$desc)
			{
			$a1c = "oef-stats_iam_{$a1[1]}";
			$a2c = "oef-stats_iam_{$a2[1]}";
			$a3c = "oef-stats_iam_{$a3[1]}";
			$a4c = "oef-stats_iam_{$a4[1]}";
			}
		else
			{
			$a1c = "oef-stats_iam_desc";
			$a2c = "oef-stats_iam_desc";
			$a3c = "oef-stats_iam_desc";
			$a4c = "oef-stats_iam_desc";
			}

		if ($this->printerFormat && !$desc)
			{
			$sc = " oef-stats_iam_tbl_cell_pf";
			$a1c .= "_pf";
			$a2c .= "_pf";
			$a3c .= "_pf";
			$a4c .= "_pf";
			}

		$d .= "<table class='oef-stats_iam_tbl'>";
		$d .= "<tr>";
		$d .= "<td class='oef-stats_iam_tbl_cell{$sc} {$a1c}'>{$a1[0]}</td>";
		$d .= "<td class='oef-stats_iam_tbl_cell{$sc} {$a2c}'>{$a2[0]}</td>";
		$d .= "<td class='oef-stats_iam_tbl_cell{$sc} {$a3c}'>{$a3[0]}</td>";
		$d .= "<td class='oef-stats_iam_tbl_cell{$sc} {$a4c}'>{$a4[0]}</td>";
		$d .= "</tr>";
		$d .= "</table>";

		/*
		$d .= "<div class='oef-stats_iam_con'>";
		$d .= "<div class='oef-stats_iam {$a1c}'>{$a1[0]}</div>";
		$d .= "</div>";

		$d .= "<div class='oef-stats_iam_con'>";
		$d .= "<div class='oef-stats_iam {$a2c}'>{$a2[0]}</div>";
		$d .= "</div>";

		$d .= "<div class='oef-stats_iam_con'>";
		$d .= "<div class='oef-stats_iam {$a3c}'>{$a3[0]}</div>";
		$d .= "</div>";

		$d .= "<div class='oef-stats_iam_con'>";
		$d .= "<div class='oef-stats_iam {$a4c}'>{$a4[0]}</div>";
		$d .= "</div>";

		//$d .= "</div>";
		*/
		return $d;
		}


	function ByAll ($score, $average)
		{
		$d .= $this->Score($score, $average);
		return $d;
		}


	function DetermineAverages ($uid = null)
		{
		if ($uid == null)
			{
			$u = 'global';
			}
		else
			{
			$u = $uid;
			$anduser = " && `user` = '" . DB::Escape($uid) . "'";
			}
		if ($this->cacheDuration > 0)
			{
			$andtime = " && `time` > '" . (time() - ($this->cacheDuration * 60)) . "'";
			}
		else
			{
			$this->GenerateAverages($uid);
			return;
			}
		$q = "SELECT * FROM `" . TBLPRE . "averages` WHERE `survey` = '" . DB::Escape($this->survey) . "'{$andtime}{$anduser} ORDER BY `time` DESC LIMIT 1";
		$res = DB::Query($q);
		$this->totalevaluations = @mysql_num_rows($res);
		// check to see recent/cached averages are available
		if ($this->totalevaluations > 0)
			{
			$r = mysql_fetch_array($res, MYSQL_ASSOC);
			$allarray = explode("\n", $r['all']);
			$allcount = 1;
			foreach ($allarray as $l)
				{
				//$this->rarray["{$u}"]["all"] = count($array);
				$this->average["{$u}"]['all']["{$allcount}"] = $l;
				$allcount++;
				}
			// position stats
			for ($i = 1; $i <= 4; $i++)
				{
				$array = explode("\n", $r["iam_{$i}"]);
				$count = 1;
				foreach ($array as $l)
					{
					$this->average["{$u}"]["iam_{$i}"]["{$count}"] = $l;
					$count++;
					}
				if ($r["iam_{$i}_list"] != null)
					{
					$array = explode("\n", $r["iam_{$i}_list"]);
					$this->rcounts["{$u}"]["iam_{$i}"] = count($array);
					foreach ($array as $l)
						{
						if ($l != null)
							{
							$this->rarray["{$u}"]["iam_{$i}"][] = $l;
							}
						}
					}
				else
					{
					$this->rcounts["{$u}"]["iam_{$i}"] = 0;
					}
				}
			// write-in stats
			if ($r['writeins'] != null)
				{
				$warray = explode("\n", rtrim($r['writeins']));
				foreach ($warray as $w)
					{
//echo "($w)";
					list($w_id, $w_person, $w_response) = explode("|", $w);
					$this->wresults["{$u}"]["{$w_id}"]["{$w_person}"] = $w_response;
					}
				}
			}
		// generate the averages now
		else
			{
			$this->GenerateAverages($uid);
			}
		}


	function GenerateAverages ($uid = null)
		{
		if ($uid == null)
			{
			$u = 'global';
			$anduser .= " && `iam` != '4'";
			}
		else
			{
			$u = $uid;
			$anduser = " && `assessed` = '" . DB::Escape($uid) . "'";
			}
		$this->sums = array();
		$this->tots = array();
		$q = "SELECT * FROM `" . TBLPRE . "evaluations` WHERE `survey` = '" . DB::Escape($this->survey) . "'{$anduser}";
//echo $q;
		$res = DB::Query($q);
		if (@mysql_num_rows($res) > 0)
			{
			while ($r = mysql_fetch_array($res))
				{
				// run through the results
				$questions = explode("\n", $r['questions']);
				$qid = 1;
				foreach ($questions as $q)
					{
					if ($r['iam'] != 4)
						{
						$this->sums["{$u}"]['all']["{$qid}"] += $q;
						}
					$this->sums["{$u}"]["iam_{$r['iam']}"]["{$qid}"] += $q;
					if ($q != 0)
						{
						if ($r['iam'] != 4)
							{
							$this->tots["{$u}"]['all']["{$qid}"]++;
							}
						$this->tots["{$u}"]["iam_{$r['iam']}"]["{$qid}"]++;
						}
					$qid++;
					}
				$iamid = $r['iam'];
				$this->rarray["{$u}"]["all"][] = $r['eid'];
				$this->rarray["{$u}"]["iam_{$iamid}"][] = $r['eid'];
				if (!isset($this->rcounts["{$u}"]["iam_{$iamid}"]))
					{
					$this->rcounts["{$u}"]["iam_{$iamid}"] = 1;
					}
				else
					{
					$this->rcounts["{$u}"]["iam_{$iamid}"]++;
					}
				// write-in stats
				if ($r['writeins'] != null)
					{
					$warray = explode("\n", rtrim($r['writeins']));
					$wcount = 1;
					foreach ($warray as $w)
						{
						$this->wresults["{$u}"]["{$wcount}"]["{$r['eid']}"] = $w;
						$wcount++;
						}
					}
				}
			}
		// generate the all averages
		$array = $this->sums["{$u}"]['all'];
		$qid = 1;
		if ($array != null)
			{
			foreach ($array as $a)
				{
				if ($a == 0)
					{
					$this->average["{$u}"]['all']["{$qid}"] = 0;
					}
				else
					{
					$this->average["{$u}"]['all']["{$qid}"] = round(($a / $this->tots["{$u}"]['all']["{$qid}"]), 1);
					}
				$qid++;
				}
			}
		// generate the "i am" averages
		for ($i = 1; $i <= 4; $i++)
			{
			$array = $this->sums["{$u}"]["iam_{$i}"];
			$qid = 1;
			if ($array != null)
				{
				foreach ($array as $a)
					{
					if ($a == 0 || $this->tots["{$u}"]["iam_{$i}"]["{$qid}"] == 0)
						{
						$this->average["{$u}"]["iam_{$i}"]["{$qid}"] = 0;
						}
					else
						{
						$this->average["{$u}"]["iam_{$i}"]["{$qid}"] = round(($a / $this->tots["{$u}"]["iam_{$i}"]["{$qid}"]), 1);
						}
					$qid++;
					}
				}
			}
		$this->SaveAverages($uid);
		}


	function SaveAverages ($uid = null)
		{
		if ($uid == null)
			{
			$uid = 0;
			$u = 'global';
			}
		else
			{
			$u = $uid;
			}
		$iam = array();
		$array = $this->average["{$u}"]["all"];
		$allcount = 0;
		if ($array != null)
			{
			foreach ($array as $a)
				{
				$allcount++;
				$all .= "{$a}\n";
				}
			}
		for ($i = 1; $i <= 4; $i++)
			{
			$array = $this->average["{$u}"]["iam_{$i}"];
			if ($array != null)
				{
				foreach ($array as $a)
					{
					$iam["{$i}"] .= "{$a}\n";
					}
				}
			else
				{
				for ($ii = 1; $ii <= $allcount; $ii++)
					{
					$iam["{$i}"] .= "0\n";
					}
				}
			$array = $this->rarray["{$u}"]["iam_{$i}"];
			if ($array != null)
				{
				foreach ($array as $a)
					{
					$iamlist["{$i}"] .= "{$a}\n";
					}
				}
			}
		if ($this->s->winCount > 0)
			{
			for ($i = 1; $i <= $this->s->winCount; $i++)
				{
				$warray = $this->wresults["{$u}"]["{$i}"];
				if ($warray != null)
					{
					foreach ($warray as $w_i => $w_v)
						{
						$writeins .= "{$i}|{$w_i}|" . str_replace("\n", " ", $w_v) . "\n";
						}
					}
				}
			}
		$q = "INSERT INTO `" . TBLPRE . "averages` (`survey`, `user`, `all`, `iam_1`, `iam_2`, `iam_3`, `iam_4`, `iam_1_list`, `iam_2_list`, `iam_3_list`, `iam_4_list`, `writeins`, `time`) VALUES(";
		$q .= "'" . DB::Escape($this->survey) . "', ";
		$q .= "'" . DB::Escape($uid) . "', ";
		$q .= "'" . DB::Escape(rtrim($all)) . "', ";
		$q .= "'" . DB::Escape(rtrim($iam["1"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iam["2"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iam["3"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iam["4"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iamlist["1"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iamlist["2"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iamlist["3"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($iamlist["4"])) . "', ";
		$q .= "'" . DB::Escape(rtrim($writeins)) . "', ";
		$q .= "'" . DB::Escape(time()) . "'";
		$q .= ")";
		DB::Query($q);
		}




	}


?>
