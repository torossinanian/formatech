-- 
-- Table structure for table `oef_averages`
-- 

CREATE TABLE `oef_averages` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `user` int(10) NOT NULL default '0',
  `all` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_1_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_2_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_3_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam_4_list` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `oef_averages`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `oef_evaluations`
-- 

CREATE TABLE `oef_evaluations` (
  `id` int(10) NOT NULL auto_increment,
  `survey` int(3) NOT NULL default '0',
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `assessed` int(10) NOT NULL default '0',
  `title` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `department` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `manager` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `iam` tinyint(1) NOT NULL default '0',
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `oef_evaluations`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `oef_sessions`
-- 

CREATE TABLE `oef_sessions` (
  `id` int(15) NOT NULL auto_increment,
  `ip` varchar(15) character set utf8 collate utf8_unicode_ci NOT NULL,
  `host` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `itime` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`),
  KEY `name` (`name`),
  KEY `itime` (`itime`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0;

-- 
-- Dumping data for table `oef_sessions`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `oef_surveys`
-- 

CREATE TABLE `oef_surveys` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `competencies` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `questions` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `writeins` longtext character set utf8 collate utf8_unicode_ci NOT NULL,
  `created` int(10) NOT NULL default '0',
  `partner` int(10) NOT NULL default '0',
  `visible` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `oef_surveys`
-- 

INSERT INTO `oef_surveys` (`id`, `name`, `competencies`, `questions`, `writeins`, `created`, `partner`) VALUES 
(1, 'Tamayyaz Survey', '1|Impact\n2|Influence\n3|Communication\n4|Integrity and Trust\n5|Customer Focus\n6|Team Working\n7|Organization\n8|Drive\n9|Problem Solving', '1|Stimulates high achievement\n1|Inspires trust\n1|Creates commitment\n1|Treats people fairly\n1|Resolves conflicts in a constructive manner\n2|Keeps relevant parties informed and up to date\n2|Develops networks\n2|Shares expertise and information willingly\n2|Gains cooperation from others\n2|Demonstrates self-confidence\n3|Has good listening skills\n3|Questions others\n3|Is an articulate verbal communicator\n3|Can communicate in writing effectively\n3|Demonstrates positive body language\n4|Presents truthful information in an appropriate and helpful manner\n4|Consistently applies personal values to appropriately address difficult situations\n4|Stays true to his or her values, regardless of internal and external pressures\n4|Is definitely trusted to keep confidences and to protect sensitive information, even to his or her own detriment\n5|Commits to meeting the expectations and requirements of internal and external customers\n5|Builds and maintains effective relationships with clients, gains their trust and respect and finds out ways to improve services\n5|Strategically plans ways to demonstrate superior customer service \n5|Foresee clients'' future needs\n5|Coach employees toward gaining clients'' trust and respect for the organization\n6|Inspires extra effort\n6|Provides public recognition of team member contributions\n6|Creates a strong team identity\n6|Establishes the need for collaboration\n6|Empowers team members\n6|Sets challenging but realistic goals\n7|Develops specific action plans\n7|Organizes work efficiently\n7|Implements high work standards\n7|Monitors output\n8|Accepts responsibilities for outcome of decisions\n8|Takes steps to avoid obstacles\n8|Is focused on results\n8|Manages change\n8|Deters deviations from plans\n9|Distinguishes between relevant and irrelevant information easily\n9|Identifies patterns or relationships from information and events\n9|Uses concepts or models to analyse situations\n9|Develops creative solutions to problems\n9|Seeks information from a variety of sources', 'What are the most important (1-3) things this person should START DOING to increase his/her effectiveness as a teammate?\nWhat are the most important (1-3) things this person should STOP DOING as they limit his/her effectiveness as a teammate?\nWhat are the most important (1-3) things this person should CONTINUE DOING to maintain his/her greatest strengths as a teammate?', 1268482266, 8);

-- --------------------------------------------------------

-- 
-- Table structure for table `oef_users`
-- 

CREATE TABLE `oef_users` (
  `id` int(10) NOT NULL auto_increment,
  `creator` int(10) NOT NULL default '0',
  `name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(60) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  `type` int(2) NOT NULL default '0',
  `company` varchar(150) character set utf8 collate utf8_unicode_ci NOT NULL,
  `eac` varchar(32) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `oef_users`
-- 

INSERT INTO `oef_users` (`id`, `creator`, `name`, `first_name`, `last_name`, `email`, `password`, `type`, `company`) VALUES 
(1, 0, 'admin', 'John', 'Doe', '', '1a1dc91c907325c69271ddf0c944bc72', 2, '');

