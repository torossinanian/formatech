<?php
define(MYSQL_HOST, "ss360eval.db.5324370.hostedresource.com");
define(MYSQL_USER, "ss360eval");
define(MYSQL_PASS, "v5KVJGxcCZvTqF");
define(MYSQL_DBNM, "ss360eval");
define(TBLPRE, "oef_");
define(BASE_URL, "http://www.tamayyaz.com/360Feedback");
define(NENE, "info@tamayyaz.com");
?>